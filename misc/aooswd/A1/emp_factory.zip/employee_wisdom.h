#ifndef _EMPLOYEE_WISDOM_H
#define _EMPLOYEE_WISDOM_H

#include "employee.h"

class EmployeeWisdom
{
 public:
  EmployeeWisdom();
  void displayWisdom (Employee* e);
};

inline EmployeeWisdom::EmployeeWisdom ()
{
}

inline void EmployeeWisdom::displayWisdom (Employee* e)
{
  e -> wisdom();
}

#endif
