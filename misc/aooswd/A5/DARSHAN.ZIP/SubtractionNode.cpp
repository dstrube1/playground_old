#include "SubtractionNode.h"

   SubtractionNode :: SubtractionNode(TreeInterface* t1, TreeInterface* t2)
   { 
      tree1 = t1;
      tree2 = t2;
   }
   string SubtractionNode :: toString()
   {
      return "(" + tree1->toString() + "-" + tree2->toString() + ")";
   }

   int SubtractionNode :: calculate ()
   {
      return tree1->calculate() - tree2->calculate();
   }
