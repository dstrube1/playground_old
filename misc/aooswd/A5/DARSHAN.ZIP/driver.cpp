/*
     Darshan Patel
     CSIS 4650
     Dr.Gayler
     03/11/03
     Assignment # 5

*/

#include <string>
#include "Tree.h"
#include "TreeInterface.h"
#include "TimeDecorator.h"

   int main()
   
   {
   
      TreeInterface* a = new Tree (5);
      TreeInterface* b = new Tree (3);
      TreeInterface* c = new Tree (2);
      TreeInterface* d = new Tree (10);
      TreeInterface* e = new Tree ("-", a);
      TreeInterface* f = new Tree ("-", c);
      TreeInterface* g = new Tree ("*", b , f);
      TreeInterface* h = new Tree ("+", e , g); 
      TreeInterface* i = new Tree ("*", c , a);
      TreeInterface* j = new Tree ("+", d , i);
      TreeInterface* k = new Tree ("*", h , j);
      TreeInterface* l = new TimeDecorator(k);
   
      int calculate = l -> calculate();
      cout << l -> toString() << " = " ;
		cout << calculate;
      
      return 0;
   
   }