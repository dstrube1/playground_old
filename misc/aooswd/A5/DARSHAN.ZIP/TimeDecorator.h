#ifndef TIME_DECORATOR_H
#define TIME_DECORATOR_H
#include <strstream>

#include "time.h"
#include <string>
#include "DecoratorTree.h"

   class TimeDecorator : public DecoratorTree
   {
   public:
		TimeDecorator();
      TimeDecorator(TreeInterface* t);
      int calculate();
		string toString();
   private:
      tm start;
      tm finish;
		int diff;
      TreeInterface* tree;
   
   };

	inline TimeDecorator :: TimeDecorator()
	{
	   diff = 0;
	}
#endif