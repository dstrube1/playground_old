#ifndef DATA_NODE_H
#define DATA_NODE_H
#include <string>
#include "Tree.h"


   class DataNode : public Node
   
   {
   public:
      DataNode(int i);
   		//Pre:
   		//Post:Default constructor for Data Node
      string toString();
   		//Pre:
   		//Post:Returns the string on the Data in the Data Node
      int calculate();
   		//Pre:
    		//Post:Returns the value stored in the Data Node
   private:
      int j;
   };

#endif  