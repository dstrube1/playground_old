#ifndef TREE_H
#define TREE_H
#include <string>
#include "Node.h"
#include "TreeInterface.h"

   class Tree : public TreeInterface
   
   {
   public:
      Tree();
   		//Pre:
      	//Post:Default Constructor
      Tree(int num);
   		//Pre:
      	//Post:Constructor for an Data Node
      Tree(string op, TreeInterface* t1);
   		//Pre:
      	//Post:Constructor for Unary Node
      Tree(string op, TreeInterface* t1, TreeInterface* t2);
   		//Pre:
      	//Post:Constructor for Binary Node
      string toString();
   		//Pre:
      	//Post:Converts the expression tree to a string
      int calculate();
   		//Pre:
      	//Post:Calculates the expression tree and returns the interger
   private:
      Node* node;
   };

#endif  