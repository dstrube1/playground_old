#ifndef UNARY_NODE_H
#define UNARY_NODE_H
#include "Tree.h"
#include <string>


   class UnaryNode: public Node
   
   {
   public:
      UnaryNode(string op, TreeInterface* t1);
   		//Pre:
    		//Post:Constructs a Unary Node
      string toString();
   		//Pre:
    		//Post:Converts the unary node to string
      int calculate();
   		//Pre:
    		//Post: calculates the unary node and returns its value
   private:
      string op_u;
      TreeInterface* tree;
   };
#endif