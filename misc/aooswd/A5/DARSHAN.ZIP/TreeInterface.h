#ifndef TREEINTERFACE_H
#define TREEINTERFACE_H

#include <string>

   class TreeInterface
   {
   public:
      virtual int calculate()=0;
   
      virtual string toString()=0;
   
   protected:
      TreeInterface();
   };
   inline TreeInterface :: TreeInterface()
   {}


#endif
