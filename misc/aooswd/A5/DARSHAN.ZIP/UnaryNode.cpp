#include "UnaryNode.h"


   UnaryNode :: UnaryNode(string op , TreeInterface* t1)
   
   {
      op_u = op;
      tree = t1;
   }


   string UnaryNode :: toString()
   
   {
      return  op_u + tree->toString(); 
   }


   int UnaryNode :: calculate()
   
   {
      return (-(tree->calculate()));
   }