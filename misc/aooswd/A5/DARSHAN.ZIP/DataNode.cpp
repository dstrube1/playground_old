#include <sstream>
#include "DataNode.h"


   DataNode :: DataNode (int i)
   
   {
      j = i;
   }


   string DataNode :: toString()
   
   {
      ostringstream outstr;
      outstr << j; 
      return outstr.str();
   }


   int DataNode :: calculate()
   
   {
      return j;
   }


