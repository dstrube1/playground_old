#include "Tree.h"
#include "UnaryNode.h"
#include "DataNode.h"
#include "AdditionNode.h"
#include "SubtractionNode.h"
#include "MultiplyNode.h"
#include "DivisionNode.h"

#include <string>


   Tree :: Tree()
   
   {}

   Tree :: Tree(int num) : node(new DataNode(num))
   
   {}


   Tree :: Tree (string op, TreeInterface* t1): node(new UnaryNode(op,t1))
   
   {}


   Tree :: Tree (string op, TreeInterface* t1, TreeInterface* t2)
   
   {
		if(op == "+")
      {
         node = new AdditionNode(t1, t2);
      }
      if(op == "-")
      {
         node = new SubtractionNode(t1, t2);
      }
      if(op == "*")
      {
         node = new MultiplyNode(t1, t2);
      } 
      if(op == "/")
      {
         node = new DivisionNode(t1, t2);
      }
	}


   string Tree :: toString()
   
   {
      return node -> toString(); 
   }


   int Tree :: calculate()
   
   {
      return node -> calculate();
   }
