#ifndef ADDITION_NODE_H
#define ADDITION_NODE_H

#include "BinaryNode.h"
#include "Tree.h"

   class AdditionNode : public BinaryNode
   {
   public:
      AdditionNode(TreeInterface* t1, TreeInterface* t2);
      string toString();
      int calculate();
   private:
      TreeInterface* tree1;
      TreeInterface* tree2;
   };    

#endif