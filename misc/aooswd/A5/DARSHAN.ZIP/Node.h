#ifndef NODE_H
#define NODE_H


   class Node
   
   {
   public:
      Node();
   		//Pre:
      	//Post: Default constructor
      virtual string toString() = 0;
   		//pure virtual finction
      virtual int calculate() = 0;
   		//pure virtual function for calculation
      virtual ~Node();
   		//virtual destructor for node
   };

   inline Node :: Node()
   
   {}

   inline Node :: ~Node()
   
   {}
#endif
