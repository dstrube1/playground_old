#include "MultiplyNode.h"

   MultiplyNode :: MultiplyNode(TreeInterface* t1, TreeInterface* t2)
   { 
      tree1 = t1;
      tree2 = t2;
   }
   string MultiplyNode :: toString()
   {
      return "(" + tree1->toString() + "*" + tree2->toString() + ")";
   }

   int MultiplyNode :: calculate ()
   {
      return tree1->calculate() * tree2->calculate();
   }


