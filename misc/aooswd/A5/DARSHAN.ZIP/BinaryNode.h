#ifndef BINARY_NODE_H
#define BINARY_NODE_H

#include <string>
#include "Tree.h"


   class BinaryNode : public Node
   
   {
   public:
      BinaryNode ();
   		//Pre:
    		//Post: Opertor string and two trees to perform the binary operation
      virtual string toString() = 0;
   		//Pre:
    		//Post: Return the string of the entire tree
      virtual int calculate() = 0;
   		//Pre:
    		//Post: Returns the calulation of the tree
   };

   inline BinaryNode :: BinaryNode()
   {}
#endif  