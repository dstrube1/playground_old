#ifndef DECORATOR_TREE_H
#define DECORATOR_TREE_H

#include "TreeInterface.h"

   class DecoratorTree : public TreeInterface
   {
   public:
      DecoratorTree(TreeInterface*t);
      virtual string toString();
		virtual int calculate();
   protected:
      DecoratorTree();
   private:
      TreeInterface* tree;
	};
	
	
	inline DecoratorTree::DecoratorTree()
   {
   }

   inline DecoratorTree::DecoratorTree(TreeInterface* t)
   {
      tree = t;
   }

   inline string DecoratorTree::toString()
   {
      return tree -> toString();
   }

   inline int DecoratorTree::calculate()
   {
      return tree -> calculate();
   }

   

#endif