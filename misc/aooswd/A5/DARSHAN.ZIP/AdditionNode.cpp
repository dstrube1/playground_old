#include "AdditionNode.h"

   AdditionNode :: AdditionNode(TreeInterface* t1, TreeInterface* t2)
   { 
      tree1 = t1;
      tree2=t2;
   }
   string AdditionNode :: toString()
   {
      return "(" + tree1->toString() + "+" + tree2->toString() + ")";
   }

   int AdditionNode :: calculate ()
   {
      return tree1->calculate() + tree2->calculate();
   }
