#include "DivisionNode.h"

   DivisionNode :: DivisionNode(TreeInterface* t1, TreeInterface* t2)
   { 
      tree1 = t1;
      tree2 = t2;
   }
   string DivisionNode :: toString()
   {
      return "(" + tree1->toString() + "/" + tree2->toString() + ")";
   }

   int DivisionNode :: calculate ()
   {
      return tree1->calculate() / tree2->calculate();
   }

