#ifndef MULTIPLY_NODE_H
#define MULTIPLY_NODE_H

#include "BinaryNode.h"
#include "Tree.h"

   class MultiplyNode : public BinaryNode
   {
   public:
      MultiplyNode(TreeInterface* t1, TreeInterface* t2);
      string toString();
      int calculate();
   private:
      TreeInterface* tree1;
      TreeInterface* tree2;
   };    

#endif