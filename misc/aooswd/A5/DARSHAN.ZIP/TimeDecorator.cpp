#include "TimeDecorator.h"

   TimeDecorator :: TimeDecorator(TreeInterface* t)
   :DecoratorTree(t)
   {
   }

   string TimeDecorator::toString()
   {
      ostrstream out;
      out <<"Total calculated time is: " << diff << " seconds"  << "\n" "\n"<< DecoratorTree::toString() <<ends;
      string s = out.str();
      return s;
   }


   int TimeDecorator :: calculate()
   {
      int temp;
      time_t now;
      now = time(0);
      start = *(localtime(&now));
      temp = DecoratorTree :: calculate();
      now = time(0); 
      finish = *(localtime(&now));
      diff = finish.tm_sec - start.tm_sec;
      return temp;	
   }