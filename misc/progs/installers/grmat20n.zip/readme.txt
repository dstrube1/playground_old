Graphmatica for Windows, version 2.0d
=====================================

by Keith Hertzer - Copyright (c) 2005 kSoft, Inc.
http://www.graphmatica.com/

Fri 11 Mar 2005

Files in this archive:
----------------------
README.TXT        16,368  3/11/05  -- this file
REGISTER.TXT       2,071  3/09/05  -- registration form (ASCII text)
REGISTER.RTF       3,369  3/09/05  -- registration form (WordPad/Word)
Graphmatica.exe  348,160  3/11/05  -- program file--32-bit version only
GRAPHMAT.HLP     117,256  3/09/05  -- help file/complete documentation
CornuSpiral.GR     1,106  3/08/05  \
DATAPLOT.GR        1,035  2/06/03   |
DIFEQ.GR             512  6/29/97   |
FUNCTIONS.GR         546  1/28/03   |
GRAPHMAT.GR        1,188  8/07/95   |
IMPLICIT.GR          302  1/29/03   |_ demonstration equation
INEQUAL.GR           298 12/29/96   |  list files
LOGLOG.GR            270  8/07/95   |  
ODE2.GR              500 11/02/03   |
POLAR.GR             383  8/07/95   |
TRIG.GR              432  8/07/95   |
XYDEMO.GR            439  8/07/95  /

Graphmatica can also make use of the file GRAPHMAT.INI to store setup
information, but I have not included one since if it is not found
Graphmatica simply uses its own default settings. See the help file for
information on the setup file.

System Requirements:
--------------------
Graphmatica for Win32 requires one of the following operating systems:
   Windows 95
   Windows 98
   Windows ME
   Windows NT 3.51 or 4
   Windows 2000 (this is the platform I use for development)
   Windows XP

In addition, I've received reports that Graphmatica runs properly on
Debian Linux with Wine (the Windows emulator) installed.

Graphmatica supports high-resolution (e.g. 1024x768) video modes, but
at this time it uses at most 16 colors; it does not take advantage of
256-color video modes.  A few features work best if you use a mouse or
other pointing-device, but it is not required.

Installing Graphmatica for Windows:
-----------------------------------
Run setup.exe. This will install the program, create icons, and set up
your registry so that Graphmatica starts up when you double-click on a
.GR file in Explorer.

Un-Installing Graphmatica for Windows:
--------------------------------------
Run the provided Uninstall icon. There may be a few trace files left in
the installation direcory; you can just delete them. Graphmatica does
not install files in any location other than the install directory.

Documentation:
--------------
Currently, I have not formatted the documentation in a printable form.
(Windows Help will let you print individual topics, but not the whole
manual.) If there is sufficient demand, I will offer it later either as
a plain text file or a formatted .WRI file for Windows Write. Don't be
fooled by the small size of the help file--it's compressed and actually
contains the full documentation (complete with many hyper-text links,
which I think makes it much more usable than printed documentation
anyway).

Please take the time to browse through the help file before you start using
Graphmatica, or you may never notice some of its more subtle advanced
features. Be sure to read the first three sections, which give a general
introduction, a map of the display, and basic instructions on how to enter
equations to graph.

Registering:
------------
You don't really have to, but please understand that I'm not doing this
as a community service. Feel free to make copies for your friends or
post Graphmatica on your school's web server so others can use it, but you 
must distribute it unchanged and intact. [Shareware vendors may distribute
the program freely provided they contact me first and charge less than $5
for disks/shipping/etc. and not for the program itself.] All the features
in this program are fully enabled, and it contains no nag screens or
other impediments to make you feel guilty about using it. However, if
you use it regularly and can afford to support it, please make a
contribution. Even if you can't send money, please take the time to
print and fill out the file REGISTER.TXT and send it to me at the
address below.

For a fee of $25, you can register Graphmatica. Registered users can
use the program indefinitely guilt-free, and will be notified of future
upgrades (which may be downloaded for free or requested on disk for a
nominal charge) in perpetuity.

Site licenses and special student bulk licensing plans are available.
Site license fees are $60 plus $2.50 for each copy in concurrent use.
I can accept purchase orders for transactions over $100, but otherwise
please try to write me a check. Please contact me if you are interested
for more information.

To register, print out and send in the form found in REGISTER.TXT (or
REGISTER.RTF, in Rich Text [WordPad] Format). Or you can register online
by credit card at http://www.graphmatica.com/order.html. See the last
topic in the help file for information about Shareware.

CREDIT CARD ORDERS ONLY -

You can order with MC, Visa, Amex, or Discover from DigiBuy (formerly
Public (software) Library) by calling 1-800-2424-PsL or 1-713-524-6394.

The item number for Graphmatica is #14133. DigiBuy operators are available
from 7:00 a.m. to 6:00 p.m. CST Monday-Thursday and 7:00 a.m. to
12:30 p.m. on Friday.

THE ABOVE NUMBERS ARE FOR CREDIT CARD ORDERS ONLY.
THE AUTHOR OF THIS PROGRAM CANNOT BE REACHED AT THESE NUMBERS.

Any questions about the status of the shipment of the order, refunds,
registration options, product details, technical support, volume
discounts, dealer pricing, site licenses, non-credit card orders, etc,
must be directed to kSoft at the address on the registration form

To insure that you get the latest version, DigiBuy will notify me the day
of your order and I will ship the product directly to you.

I am required by my contract with DigiBuy to ship you a disk immediately
regardless of whether you have the current version already. Therefore,
if you order through DigiBuy, you will receive the most current version
right away, as well as an upgrade to the next major release. To help
defray the additional costs, you will be charged an extra $2.50 in the
U.S. and Canada ($5 outside North America) for handling.


How to get the latest version:
------------------------------
The latest version of Graphmatica for DOS and Windows is available
on various FTP and web sites on the Internet. For the very latest
release, including beta-test versions, see the kSoft homepage:
    http://www.graphmatica.com/


How to contact me:
------------------
You will receive the fastest reply to your inquiries by sending e-mail
to ksoft@graphmatica.com. I can typically respond to quick questions
within a day or two.

I do NOT provide telephone support. Please don't try to get my number
through directory assistance, as you will probably just bother my parents.

Worst comes to worst, you can write me a letter and mail it to the address
below. I promise I will respond to it, although I can't guarantee how long
it will take.

kSoft, Inc.
345 Montecillo Dr.
Walnut Creek, CA 94595-2654

[Please make checks payable to Keith Hertzer.]

What's new in version 2.0d:
===========================
1. Fixed bug that prevented changes to the state of the labels from taking
   effect immediately when changed via the dialog box.
2. Fixed an infinte loop when graphing on base-10 log paper with the Point
   Tables on.
3. Added Unicode support to allow for more East Asian language translations.
4. Added a number of new checks to make sure you are reminded to save your
   work on closing a file after making changes other than adding/removing 
   equations.
5. Fixed implicit function graphing to not display incorrect graphs when
   given an equation with no solution.
6. Fixed reload of strict inequalities so the redrawn curve has the same
   color and dashed pattern as when originally graphed.
7. Improved detection of discontinuous functions like x=(-3)^y
8. Fixed crash attempting to change fonts when no printer was installed.
9. On Windows XP, the program automatically uses the new XP look-and-feel;
   you no longer need to copy the Graphmatica.exe.manifest file manually.

What's new in version 2.0c:
===========================
1. Mouse wheel support added to graph surface and grid control. On the graph
   surface, Shift+wheel scrolls left-right and Ctrl+wheel zooms in and out.
2. Fixed bug that prevented you from specifying values for free variables
   when they were used in an equation only through a user-defined function.
3. Fixed intermittent errors shading inequalities like "abs x - abs y > 3"
   and "x^2-y^2 < 6".
4. Fixed an issue which caused parts of circles/ellipses to disappear when
   the horizontal axis through them was too close to the edge of the screen.
5. Added option to shade the inverse of the solution for inequalities.
6. Added Options button to Integrate Curve dialog box and fixed refresh of
   integral on screen when you change the integration options.

What's new in version 2.0b:
===========================
1. Fixed crash using AutoRange when ODE flow fields are on screen.
2. Cleaned up documentation errata due to switch to tabbed dialog boxes
   (no View/Colors menu anymore, for instance)
3. Added "power function" y = ax^b to equation types available for curve fit.
4. Fixed crash on Paste Data Plot when the Data Plot Editor was not open.

What's new in version 2.0a:
===========================
1. Fixed handling of y = (1/a)^x {a: 1, 3, 1}. This graph was incorrectly
   being tagged as a discontinuous function.
2. Corrected references to the defunct Labels menu item in the help file.
3. Added safeguard to prevent you from choosing colors that are the same 
   as the background in the Colors dialog box.
4. Fixed the Set Initial Value menu item for systems of ODEs and second-
   order and higher equations.
5. Size of dots on dotted grid is now dependent on gridlinewidth parameter.
6. Fixed crash loading data plot on startup.

What's new in version 2.0:
==========================

Major Features:
---------------
 1. Limited support for graphing relations with multiple instances of both
    x and y variables. This is done by performing implicit differentiation
    with respect to both variables and plotting the resulting ODE. 
 2. New, improved Point Evaluate dialog box allows you to: 
    - Select a different equation than the current one to evaluate 
    - Solve Cartesian functions for x as well as y 
 3. New Find Intersection dialog box, which allows you to select two 
    Cartesian functions of the same variable and display either all points
    of intersection on the screen or the intersection closest to a guess
    you provide. 
 4. Added support for user defined functions. Use the Functions dialog box
    (Tools/Functions menu item) to define as many single-variable helper
    functions as you want. You can define functions in terms of the
    variable x or t, and give them any name them that does not conflict
    with built-in variables or function names. 
 5. Data plotting added. Use View/Data Plot Editor to enter any number of
    x-y data sets. 
 6. Also added curve-fitting using polynomials (up to 9th order), 
    sinusoidal, or exponential curves using the Levenberg-Marquardt
    algorithm. 
 7. Added Draw Tangent Line dialog box which, like the Integrate Curve
    dialog box, allows you to type in values rather than selecting an
    equation and tangent point with the mouse. Also added a "sticky"
    tangent line mode, which allows you to keep drawing tangent lines as
    long as you keep clicking on curves. 
 8. Consolidated most options screens into 2 tabbed dialog boxes, and
    revamped menus to remove commands that were no longer needed, plus some
    rarely-used items that can be accessed through the Settings dialog box. 
 9. Converted to implicit-save model for default settings (but you now must
    explicitly set the default for grid range and graph paper). 
10. Added context-sensitive popup menus when you right-click on the grid,
    graphs, graph labels, and point tables. 

Minor Features:
---------------
 1. Added support for decimal separators other than "." based on your
    Windows control panel settings. If your settings indicate you prefer a
    different decimal separator (say ",") then all constant values input
    and output by the program will use this separator. 
 2. Added AutoRange feature to reset the range automatically when you enter
    a new graph to ensure that all Cartesian functions are displayed
    on-screen. 
 3. Added control over number of decimal places used in Point tables to
    options dialog and fixed a problem where numbers in scientific notation
    were getting formatted with fewer decimal places than requested. 
 4. Made the Edit/Copy Graphs EMF function recalculate the graphs at
    maximum possible screen resolution. This should improve the quality of
    graphs copied and printed from Word. 
 5. Added two options to improve accessibility for visually-impaired users:
    You can now specify the width of curves when "Draw graphs with wide
    lines" is checked in the general settings dialog. The default is 2
    pixels, but you can increase it to make lines even bolder. In addition,
    you can set "gridlinewidth" in the graphmat.ini file to increase the
    width of grid lines and the axes. 
 6. Increased maximum width of axis labels from 7 to 25 characters. 
 7. The Point Tables window now uses a grid control based on "BabyGrid" by
    David Hillard rather than a standard listbox. This makes for much
    neater display of data (right-aligned numbers, resizable columns, etc).
    In addition, the Point Tables window can now be resized and has a
    system close menu. 
 8. Last directory used in File Open/Save dialog boxes is now remembered. 
 9. Improved Windows shell integration: .GR files are added to the
    Documents menu when opened, and the program opens files dragged from
    Explorer. 
10. Coordinate cursor is now always on except when it would interfere with
    display of important info (selected range, tangent line/integral info)
    in the status bar. However, you must still enable the coordinate cursor
    tool to gain keyboard control over the crosshairs. 
11. Added 2 integration methods: left-hand sums and right-hand sums. 
12. The equation of tangent lines is now displayed in the Printout window
    along with the point and slope. 
13. Added support for printing integral and tangent line information. 
14. Added support for graphing highest-order derviative in custom ODE mode
    (e.g. {vars:t,dx} graphs t vs. dx/dt for a first-order ODE). 
15. Added rand(n) function which generates a random number between 0 and n. 
16. Added "color-code" checkbox to print dialog box. This will print
    equations in the same color as their corresponding graphs when checked. 
17. Swapped out yellow for "dark yellow" in the white color scheme, since
    yellow was virtually invisible when printed. 
18. Improved High-Resolution Printing: gridline and axis thickness is now
    scaled up based on printer resolution so they're more visible at 600dpi. 
19. Added fine-tuning parameters for automatic legends and grid spacing,
    as well as manual control over grid spacing. 

Notable bug fixes:
------------------
 1. Fixed a bug which caused flow fields (ODEs without initial values) to
    graph incorrectly when the aspect ratio of the grid was not square. 
 2. Fixed a bug with the graph "y=int x" which prevented the graphing loop
    from terminating. 
 3. Fixed an annoying bug which sometimes caused the selection to be
    cleared or displayed inappropriately when you switched windows after
    selecting a portion of the grid to zoom in on. 
 4. When saving and loading a .gr file, equations are now restored with
    the same color they originally had. Also, they are restored in the same
    order as they appeared in the queue at save time, rather than backwards. 
 5. Fixed bug with specifying the domain as {y:...} for functions of y. 
