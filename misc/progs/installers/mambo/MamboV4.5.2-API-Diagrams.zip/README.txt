MAMBO API DOCUMENTS

index_flow452.pdf
-----------------
Shows diagramatically the high level execution of the sites index.php file.

Create with Open Office Draw (http://www.openoffice.org).


Core_Database_Tables.png
------------------------
Shows the default Mambo Database Tables is a diagramatic form.
Some of the major relationship are shown but many are removed
for clarity.

Created with Visual Paradigm Community Edition (http://www.visual-paradigm.com/).

------------------------

All documents copyright (C) 2000-2005 Miro International Pty Ltd.
Release under the Free Document License, http://www.gnu.org/copyleft/fdl.html

Mambo is a free content management system.  Visit these sites for mor information:

www.mamboserver.com - the official site
help.mamboserver.com - user documentation and other helpful information
forum.mamboserver.com - the official forum for Mambo
mamboforge.net - a place where you can find heaps of addons (calendars, mini-forums, etc)

There are also a couple of great community sites (among many) you can look at:

http://www.mambohut.com/ - has a huge gallery of free templates (hundreds)
http://demo451.corephp.com/ - demos of heaps of Mambo addons
