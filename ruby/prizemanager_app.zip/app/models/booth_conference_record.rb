class BoothConferenceRecord

  attr_reader :id, :name, :points, :visitors
  attr_writer :id, :name, :points, :visitors
  

  def initialize( )
    @name = nil
    @points = 0
    @visitors = 0
  end
  
end
