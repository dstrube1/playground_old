class Booth < ActiveRecord::Base

  has_many :conference_booths
  
  def self.find_by_name(name)
     return Booth.find(:first, :conditions=>["name LIKE ?",name]) 
  end
   
  def self.boothExists?(id)
    begin
      if Booth.find(id) == nil
        return false
      end
		return true
    rescue
      return false
      end
    end

end
