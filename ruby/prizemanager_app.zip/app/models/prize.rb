class Prize < ActiveRecord::Base
  has_many :conference_prizes
end
