class UserConferenceRecord
  
  attr_reader :user_id, :name, :points
  
  def initialize( p_user_id, p_name, p_points )
  
    @user_id = p_user_id
    @name = p_name
    @points = p_points
  end
  
end
