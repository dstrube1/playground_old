class User < ActiveRecord::Base

  has_many :sessions
  has_many :user_booth_points

  def self.find_by_username(user_name)
     return User.find(:first, :conditions=>["username = ?",user_name]) 
  end
  
  def self.find_by_email(email)
    return User.find(:first, :conditions=>["email = ?",email])
  end


  def self.createUser(user_name)
    user=User.new
    user.username = user_name
    begin
      user.save
      return true
    rescue
      return false
    end
  end

  def self.user_exists?(user_name)
    begin
      if User.find_by_username(user_name) == nil
        return false
      end
      return true
    rescue
      return false
      end
    end

  def self.email_exists?(email)
    begin
      if User.find_by_email(email) == nil
        return false
      end
      return true
    rescue
      return false
    end
  end

end
