class Award < ActiveRecord::Base

  has_many :conference_booth_awards
  
  def self.find_by_name(name)
     return Award.find(:first, :conditions=>["content LIKE ?",name]) 
   end
  
  def self.award_exists?(name)
    begin
      if Award.find_by_name(name) == nil
        return false
      end
		return true
    rescue
      return true
      end
    end


end
