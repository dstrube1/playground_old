class ConferencePrize < ActiveRecord::Base

  belongs_to :conference
  belongs_to :prize

end
