class ConferenceBooth < ActiveRecord::Base

  belongs_to :booth
  belongs_to :conference
  has_many  :conference_booth_awards
  has_many  :conference_booth_documents
  
  def self.find_booth_by_name(name)
     return Booth.find_by_name(name)
    end
  
  def self.boothExists?(id)
    begin
      if ConferenceBooth.find(id) == nil
        return false
      end
		return true
    rescue
      return false
      end
    end

end
