class Conference < ActiveRecord::Base

  has_many :conference_booths
  has_one  :conference_prize
  has_many :user_booth_points
    
end
