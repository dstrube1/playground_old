class UserBoothPoint < ActiveRecord::Base

  belongs_to :user
  belongs_to :conference_booth_award
  belongs_to :conference
  belongs_to :conference_booth

end
