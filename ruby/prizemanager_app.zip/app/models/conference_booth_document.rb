class ConferenceBoothDocument < ActiveRecord::Base
  belongs_to :conference_booth
  
  
end
