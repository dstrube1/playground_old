class Vendor < ActiveRecord::Base
  belongs_to :booth
  belongs_to :user
  
  def self.find_by_user(user_id)
    return Vendor.find(:first, :conditions=>["user_id = ?",user_id])
  end
  
  def self.find_by_booth(booth_id)
    return Vendor.find(:first, :conditions=>["booth_id = ?",booth_id])
  end
  
end
