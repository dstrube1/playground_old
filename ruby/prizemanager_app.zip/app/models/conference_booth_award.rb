class ConferenceBoothAward < ActiveRecord::Base

  belongs_to :conference_booth
  belongs_to :award
  
  def self.find_by_award_code(award_code)
    return ConferenceBoothAward.find(:first, :conditions=>["content LIKE ?", award_code])
  end

  def self.award_code_exists?(award_code)
    begin
      if ConferenceBoothAward.find_by_award_code(award_code) == nil
        return false
      end
      return true
    rescue
      return false
    end
  end
end
