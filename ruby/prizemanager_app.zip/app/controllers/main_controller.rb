class MainController < ApplicationController

  require 'csv'

  CONFERENCE_ID = 1;

  def view
  
    @user_id = params['user_id'];
        
    user = nil;
    
    
    unless User.user_exists?(@user_id)
	   User.createUser(@user_id)
  	end
    
    
    user = User.find_by_username(@user_id);
    
    
#    session[:user_id] = user.id;
    
    @conference_id = params['conferenceId']
    
    if @conference_id == nil 
      @conference_id = CONFERENCE_ID
    end
    
    conference = Conference.find(@conference_id)
    
    if conference == nil
      flash[:notice] = "Unable to find conference for booth #{booth.name}"
      return
    end
    
    
    conference_prize = ConferencePrize.find(:first, :conditions=>["conference_id = ?", conference.id])
    
    if conference_prize == nil
      return generate_blank_icon(max_points)
    end
    
    prize = conference_prize.prize
    
    @points_to_date = PointsCalculator.sum_user_points(conference, user)

    @points_remaining = conference_prize.total_points_required - @points_to_date

    if @points_remaining < 0
      @points_remaining = 0
    end

    if @points_remaining == 0
      @image_url = prize.won_image_url
    else
      @image_url = prize.image_url
    end

        
  
  end

  def two_pane
  end
  
  def index
    render(:action => "view");
  end
  
protected

  def old_index

    @session_key = params['session']
    @booth_id = params['booth']
    @conference_id = params['conference']
    @code = params['code']
 
    flash[:notice] = nil
 
    if @session_key == nil
      flash[:notice] = "Required Query Parameter 'session' not supplied."
      return;
    end
    
    if @booth_id == nil
      flash[:notice] = "Required Query Parameter 'booth' not supplied."
      return;
    end
    
    if @conference_id == nil
      flash[:notice] = "Required Query Parameter 'conference' not supplied."
      return;
    end
    
    if @code == nil
      flash[:notice] = "Required Query Parameter 'code' not supplied."
      return;
    end
 
    session = Session.find(:first, :conditions => ["session_key LIKE ?", @session_key])
 
    if session == nil
      flash[:notice] = "Unable to find session with key: #{@session_key}"
      return
    end
 
    user = session.user
    
    if user == nil
      flash[:notice] = "Unable to find user for session #{session.id}"
      return
    end
    
    booth = Booth.find(@booth_id)
    
    if booth == nil
      flash[:notice] = "Unable to find booth with id: #{@booth_id}"
      return
    end
    
    
    
    conference = Conference.find(@conference_id)
    
    if conference == nil
      flash[:notice] = "Unable to find conference for booth #{booth.name}"
      return
    end

    conference_booth = ConferenceBooth.find(:first, :conditions => ["booth_id = ? AND conference_id = ?", booth.id, conference.id])

    if conference_booth == nil
      flash[:notice] = "Unable to find a booth #{booth.name} at conference: #{conference.name}"
      return
    end  


    conference_prize = ConferencePrize.find(:first, :conditions=>["conference_id = ?", conference.id])

    if conference_prize == nil
      flash[:notice] = "Unable to find a prize for conference #{conference.name}"
      return
    end

    prize = conference_prize.prize
    
    if prize == nil
      flash[:notice] = "Unable to find a prize with id: #{conference_prize.id}"
      return
    end


    user_booth_points = add_booth(conference_booth, user, @code)

    

    user_points = sum_user_points(conference, user)

    


    @username = user.username
    @session_id = session.id
    @booth_name = booth.name
    @conference_name = conference.name
    @booth_points = conference_booth.points
    @total_points = conference_prize.total_points_required
    @prize_name = prize.name
    @points_to_date = user_points
    @points_awarded = user_booth_points.points
    @number_of_guesses = user_booth_points.guesses
    @booth_code = conference_booth.code        
    @total_guesses = conference_prize.max_guesses
    
    

    
#    render_text "Session Key: #{@session_key}<br />Booth Id: #{@booth_id}"
  
  
  end

end

