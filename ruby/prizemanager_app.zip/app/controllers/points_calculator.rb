class PointsCalculator


protected
  def self.sum_user_points( conference, user)

    points = UserBoothPoint.find(:all, :conditions=>["conference_id = ? AND user_id = ?", conference.id, user.id])

    #logger.debug("So far user: #{user.username} has visited #{points.length} booths.")

    sum = 0
    
    points.each do |p|
      sum += p.points
    end

    #logger.debug("Total points so far for user #{user.username} at conference: #{conference.name}: #{sum}")

    return sum

  end
  
  def self.get_or_build_user_booth_point(user, cba)
  
    ubp = UserBoothPoint.find(:first, :conditions=>["user_id = ? AND conference_booth_award_id = ?", user.id, cba.id])

    if ubp == nil
    
      ubp = UserBoothPoint.new
      
      ubp.user = user
      ubp.conference_booth_award = cba
      ubp.points = 0
      ubp.guesses = 0
      ubp.conference = cba.conference_booth.conference
      ubp.conference_booth = cba.conference_booth

      begin    
        ubp.save()
      rescue
        logger.error("Unable to save newly created UserBoothPoint object.")    
      end
    end

    return ubp
  
  end
    
end
