class FulfillmentController < ApplicationController

  def add_points
    #Objective: add row to user_booth_points for a given user with a given award_code
    
	#get the user id and award code and verify they are valid
	user_id = params['user_id']
	award_code = params['award_code']
  
    unless User.user_exists?(user_id)
	   User.createUser(user_id)
  	end

    unless ConferenceBoothAward.award_code_exists?(award_code)
	    flash[:notice] = "Invalid award code: #{award_code}"
      return
	end

  #flash[:notice] = "OK"
  #return

#based on the award_code / content, update user_booth_points with the new point_value 
	award = ConferenceBoothAward.find(:first, :conditions=>["content = ?", award_code])

	user = User.find_by_username(user_id)
	user_booth_point = PointsCalculator.get_or_build_user_booth_point(user, award)
	add_award(user_booth_point)
    
    flash[:notice] = "Successfully added points for user #{user_id}"
 
end

protected 

  def validate_code
  
    cba = params['conference_booth_award']
    answer_map = params['answer']
  
    if cba == nil
      flash[:notice] = "Conference Booth Award Id was not supplied.  Cannot continue."
      return
    end
  
    @conference_booth_award = ConferenceBoothAward.find(cba['id'])
    
    if @conference_booth_award == nil
      flash[:notice] = "Unable to find a Conference Booth Award with ID: #{cba['id']}"
      return
    end

    if answer_map == nil
      flash[:notice] = "Unable to find the secret code."
      return
    end


    if session[:user_id] == nil
      flash[:notice] = "Unable to find the user for whom this award is to be given."
      return
    end

    user = User.find(session[:user_id])
    
    code = answer_map['code']
    correct_answer = @conference_booth_award.content
    

    result = validate_user_answer(user, @conference_booth_award, correct_answer, code)    

    conference = @conference_booth_award.conference_booth.conference

    @points_to_prize = conference.conference_prize.total_points_required
    @user_points_so_far = PointsCalculator.sum_user_points(conference, user)
    @user_points_to_go = @points_to_prize - @user_points_so_far

    if result == 'correct'
    
      
    
      render(:action=>"correct_answer")
    else 
      if result == 'error'
        render(:action=>"fulfillment_error")
      else
        render(:action=>"incorrect_answer")
      end    
    end
    
  end

  def validate_survey
  
    userid = params[:userid]
    cba_id = params[:cba]
    code = params[:code]
    
    if userid == nil 
      flash[:notice] = "userid was not specified. Cannot continue."
      logger.debug("userid not specified.")
      render("service_error")
      return
    end
    
    if cba_id == nil
      flash[:notice] = "cba was not specified.  Cannot continue."
      render("service_error")
      return
    end

    


    begin
      conference_booth_award = ConferenceBoothAward.find(cba_id)            
    rescue
      flash[:notice] = "Unable to find a cba with id: #{cba_id}"
      render("service_error")
      return
    end  
    
    begin
      user = User.find(userid)
    rescue
      flash[:notice] = "Unable to find a user with id: #{userid}"
      render("service_error")
      return
    end

    if conference_booth_award.award.award_type != "survey"
      flash[:notice] = "Incorrect award type.  Award for cba #{cba_id} must be of type 'survey'."
      render("service_error")
      return
    end
    
    if conference_booth_award.content == code
        
      user_booth_point = PointsCalculator.get_or_build_user_booth_point(user, conference_booth_award)
      add_award(user_booth_point)
      
      
    
    else
      flash[:notice] = "Incorrect confirmation code for cba #{cba_id}"
      logger.debug("User #{userid} had invalid code #{code} entered for cba #{cba_id}.  Possible hacking activity.")
      render("service_error")
      return
    end
      
  end

  def fulfill_award
  
    @conference_booth_award_id = params['id']
    
    if @conference_booth_award_id == nil
      flash[:notice] = "Query parameters do not include the award id."
      return
    end     
    
    @conference_booth_award = ConferenceBoothAward.find(@conference_booth_award_id)
    
    if @conference_booth_award == nil
      flash[:notice] = "There is no Booth award with id: #{@conference_booth_award_id}"
      return
    end 
    
    @award = @conference_booth_award.award

  end

  def validate_user_answer(user, cba, correct_answer, user_answer)

    logger.debug("User #{user.username} entered: #{user_answer} and answer for CBA: #{cba.id} is: #{correct_answer}")


    conference_prize = ConferencePrize.find(:first, :conditions=>["conference_id = ?", cba.conference_booth.conference.id])

    user_booth_point = PointsCalculator.get_or_build_user_booth_point(user, cba)
    
    if user_booth_point == nil
      flash[:notice] = "Unable to find or create a record of the user's visit to the specified booth."
      return 'error'
    end

    if conference_prize == nil
      flash[:notice] = "Unable to find the prize rules/restrictions for the conference."
      return 'error'
    end

    user_booth_point.guesses += 1

    @current_guesses = user_booth_point.guesses
    
    @max_guesses = conference_prize.max_guesses

    @remaining_tries = @max_guesses - @current_guesses

    if (@current_guesses < @max_guesses)
      
      if correct_answer == user_answer
      
        add_award(user_booth_point)
        return 'correct'
      else
        user_booth_point.points = 0
      end
    end
    
    begin
      user_booth_point.save()
    rescue
      logger.error("Unable to save user #{user_booth_point.user.username}'s failed guess.")
    end
    
    return 'incorrect'
  
  end

  def add_award( user_booth_point )
  
    cba = user_booth_point.conference_booth_award
  
    user_booth_point.points = cba.point_value
  
    begin
      user_booth_point.save()
    rescue
      logger.error("Unable to save user #{user_booth_point.user.username}'s correct guess.")
    end
  end

  

  
end
