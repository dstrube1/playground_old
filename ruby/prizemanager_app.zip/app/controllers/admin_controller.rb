class AdminController < ApplicationController

  def index
  
    render(:action => "login")
  
  end


  def login
  end


  def do_login
  
    if params[:login] == nil
      flash[:notice] = "No username or password supplied."
      render :action => "login"
      return 'error'
    end
  
    username = params[:login][:username]
    password = params[:login][:password]
  
    user = User.find_by_username(username)
  
    if (user == nil)
      flash[:notice] = "No user found by username: #{username}"
      render(:action => "login")
      return 'error'
    end
    
    if ((password == nil || password == "") || user.password == nil || user.password != password)     
      flash[:notice] = "Invalid password."      
      render(:action => "login")
      return 'error'
    end
        
    session[:user_id] = user.id

    if (session[:user_action] != nil)     
      redirect_to(:action => session[:user_action])
      return 'success'
    end 
    
    if Vendor.find_by_user(user.id) == nil
      render(:action => "admin_welcome")
    else
      render(:action => "vendor_welcome")
    end

    return 'success'
      
  end
  
  
  def do_logout
  
    session[:user_id] = nil
    session[:user_action] = nil
    
    flash[:notice] = "You have been logged out."

    render(:action => "login")
    
    return 'success'
  
  end


  def create_booth
  
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "create_booth"
      render(:action => "login")
      return
      
    end
    @conferences = Conference.find(:all)
  end
  
  
  def do_create_booth
  
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "create_booth"
      render(:action => "login")
      return
      
    end
  
    conference_id = params[:booth][:conference]
    booth_name = params[:booth][:name]
    max_points = params[:booth][:max_point_value]
    booth_url = params[:booth][:booth_url]
    
    problems = ""
    
    if Booth.find_by_name(booth_name) != nil
      problems += "<br>A booth by that name already exists"
    elsif booth_name ==""
      problems += "<br>Booth name must not be blank."
    end
    
    if max_points ==nil
      flash[:notice] = "Maximum point value must not be null"
      #^ not added to problems because if the above condition is true, 
      #then the controller will break on the next conditional and cause an ugly error
      return
    end
    
    if max_points.to_i <= 0
      problems += "<br>Maximum point value must be a number greater than 0"
    end
    
    if problems.length > 0
      flash[:notice] = problems
      return
    end
    
    new_booth = Booth.new
    new_booth.name = booth_name
    new_booth.booth_url = booth_url
    begin
      new_booth.save
    rescue
      flash[:notice] = "Error adding booth #{booth_name} to Booths"
      return
    end
    
    #now get the booth_id
    booth_id = Booth.find_by_name(booth_name).id
    new_conference_booth = ConferenceBooth.new
    new_conference_booth.conference_id = conference_id
    new_conference_booth.booth_id = booth_id
    new_conference_booth.max_points = max_points
    begin
      new_conference_booth.save
    rescue
      flash[:notice] = "Error adding conference booth #{booth_name} to Conference Booths"
      return
    end
    
    #render_text ()
    
    flash[:notice] = "Successfully added booth #{booth_name} to conference.";
    
    render(:action => "welcome");
    
  end


  def upload_users
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "upload_users"
      render(:action => "login")
      return
      
    end
  end


  def do_upload_users
    
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "upload_users"
      render(:action => "login")
      return
      
    end
    
#    input should be something like this:
#    ---users.csv
#      username,first name,last name,email
#      bob1,bob,smith,bob@smith.com
#      j1,jack,johnson,jj@j.j
#      test1,t,t,t@t.t
#      1,1,1,johnbr@gmail.com

    tmp = {}
    
    tmp[:name] = params[:file][:name]
    tmp[:data] = params[:file][:data].read
    filename = params[:file][:data].original_filename
    
    if filename =="" || filename ==nil
      flash[:notice] = "<a href=upload_users>Please enter a filename.</a>"
      return
    end
    
    if File.extname(filename) != ".csv"
      flash[:notice] = "#{filename} is not a csv file"
      return
    end

    users = tmp[:data]
    
    #2D hash of user data
    h = {},{}
    #horizontal index
    xi = 0 
    #vertical index
    vi = 0
    
    #Constants in Ruby are specified by all caps
    #this is cool, but cannot use the same constant name in two functions
    header_row = 1
    username_column = 1
    first_name_column = 2
    last_name_column = 3
    email_column = 4
    
    output=""
    #output+= "users data= #{users}<br><br>"
        
    users.each do |user| 
    
      #output += "user row: #{xi}: #{user}<br>"
    
      xi+= 1
      vi = 0
      user.split(',').each do |u|
        vi += 1
        
        #h[xi] = {}
        if h[xi] == nil
          h[xi] = {}
        end
        h[xi][vi] = u
        #output += "H at [#{xi}][#{vi}] = #{h[xi][vi]}<br>"
      end
    end    
    
    xi=0
    vi=0
    username = ""
    first_name = ""
    last_name = ""
    email = ""
    h.each do |row|
      #output+= "Row = #{xi}, "
      row.each do |col|
        #output+= "col = #{vi}, h=#{h[xi][vi]}; "
        if xi>header_row
          if vi==username_column
            if User.user_exists?(h[xi][vi])
              #output+= "username = #{h[xi][vi]}<br> "
              flash[:notice] = "<br>At line #{xi}, user '#{h[xi][vi]}' already exists<br>"
              return
              #this works:
              #h[xi] = {}
              #the following only deletes the username, not the row:
              #h[xi].delete(vi)
            else
              username = h[xi][vi].chomp
            end
          elsif vi==first_name_column
            first_name = h[xi][vi].chomp
          elsif vi ==last_name_column
            last_name = h[xi][vi].chomp
          elsif vi==email_column 
            unless is_email?(h[xi][vi])
              h[xi][vi] = {}
            end          
            if User.email_exists?(h[xi][vi])
              flash[:notice] = "<br>At line #{xi}, email '#{h[xi][vi]}' already exists<br>"
              return
            else
              email = h[xi][vi].chomp
            end
          end
        end
        vi+=1
      end
      xi+=1
      vi=1
      #This user did not fail, safe to add it at the end of the testing loop
      if username != ""
        new_user = User.new
        new_user.username = username
        new_user.first_name = first_name
        new_user.last_name = last_name
        new_user.email = email
        begin
          new_user.save
        rescue
          flash[:notice] = "<br>Error adding user #{username}<br>"
          return
        end
      end
    end
    
    #http://blade.nagaokaut.ac.jp/cgi-bin/scat.rb/ruby/ruby-talk/153088 :
    #hoh = lambda { Hash.new {|h,k| h[k] = hoh.call} }
    #http://blade.nagaokaut.ac.jp/cgi-bin/scat.rb/ruby/ruby-talk/29941 :
    #MyHash = Hash.new
    #http://walrus-ruby.hp.infoseek.co.jp/perlvalue/perlvalue.rb
    
    flash[:notice] = output

  end #do_upload_users


  def add_prize_data

    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "add_prize_data"
      render(:action => "login")
      return
    end

    @conference_booths = ConferenceBooth.find(:all);
    @awards = Award.find(:all);
    end


  def do_add_prize_data

    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "add_prize_data"
      render(:action => "login")
      return
    end

    #Objective: add valid row to conference_booth_awards
    
    conference_booth_id = params[:prize][:booth]
    award_id = params[:prize][:award]
    point_value = params[:prize][:point_value]
    content_url = params[:prize][:content_url]
    content = params[:prize][:content]
    
    problems = ""
    
    max_points = 10
    if ConferenceBooth.boothExists?(conference_booth_id)
      max_points = ConferenceBooth.find(conference_booth_id).max_points.to_i
    else
      problems += "<br>Booth #{conference_booth_id} has not been added to this conference."
    end
        
    if Award.find(award_id) ==nil
      problems += "<br>Award #{award_id} does not exist."
    end
    
    if point_value ==nil
      flash[:notice] = "Point value must not be null"
      #^ not added to problems because if the above condition is true, 
      #then the controller will break on the next conditional and cause an ugly error
      return
    end
    
    if point_value.to_i <= 0
      problems += "<br>Point value must be a number greater than 0"
    elsif point_value.to_i >max_points
      problems += "<br>Point value must be less than or equal to #{max_points}"
    end
    
    combo_test = ConferenceBoothAward.find(:first, :conditions=>["conference_booth_id = ? 
    AND award_id = ?", conference_booth_id, award_id]) 
    
    if combo_test != nil
      problems += "<br>This booth / award combination (#{conference_booth_id} / #{award_id}) 
      already exists at this conference."
    end
    
    #flash[:notice] = "conference_booth_id = #{conference_booth_id}"
    
    #flash[:notice] = "point_total_for_conference_booth(conference_booth_id) = #{point_total_for_conference_booth(conference_booth_id)}"
    #return
    
    if (point_total_for_conference_booth(conference_booth_id) + point_value.to_i) >max_points
      problems += "<br>Total points for this conference booth cannot be greater than #{max_points}. This total 
      would be #{point_total_for_conference_booth(conference_booth_id) + point_value.to_i}"
      end

    if ConferenceBoothAward.find_by_award_code(content)
      problems += "<br>The award security code you entered: #{content} is already in use.  Please use another."          
    end

    
    if problems.length > 0
      flash[:notice] = problems
      return
    end
    
    
    entry=ConferenceBoothAward.new
    entry.conference_booth_id = conference_booth_id
    entry.award_id = award_id
    entry.point_value = point_value
    entry.content_url = content_url
    entry.content = content
    begin
      entry.save
      flash[:notice] = "Successfully added #{point_value} point value award to booth: #{entry.conference_booth.booth.name}" 
      #{conference_booth_id}; award_id: #{award_id}";
      render(:action => "welcome");
      return true
    rescue
      flash[:notice] = "Error adding these : conference_booth_id: 
      #{conference_booth_id}; award_id: #{award_id}; point_value #{point_value}";
      return false
      end
    
    end
    
  
  def upload_emails
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "upload_emails"
      render(:action => "login")
      return
      
    end
    @conferences = Conference.find(:all);
  end


  def do_upload_emails
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "upload_emails"
      render(:action => "login")
      return
      
    end
    
#    input should be something like this:
#    ---email.csv
#    username,email
#    bob1,j1@j.com
#    j1,bob@smith.com
#    j1,j1@j.com
#    j1,johnbr@gmail.com
#    j1,j1@i.com
#    j1,h@k.com
#    j1,1@2.com
#    j1,2@3.com
    
    
    tmp = {}
    
    tmp[:name] = params[:file][:name]
    tmp[:data] = params[:file][:data].read
    filename = params[:file][:data].original_filename
    conference_id = params[:file][:conference]
    
    if filename =="" || filename ==nil
      flash[:notice] = "<a href=upload_emails>Please enter a filename.</a>"
      return
    end
    
    if File.extname(filename) != ".csv"
      flash[:notice] = "#{filename} is not a csv file"
      return
    end

    emails = tmp[:data]
    
    #2D hash of email data
    h = {},{}
    #horizontal index
    xi = 1 
    #vertical index
    vi = 1 
    #1D list of unique emails
    unique_emails = {}
    ue_i=1
    
    output = ""
    header_row = 1
    username_column= 1
    email_column = 2
    #output="#{emails}<br>"
    
    cba = ConferenceBoothAward.find(:all, :conditions=>["conference_booth_id = ? ",0])
    
    #populate h with data
    emails.each do |email| 
      email.split(',').each do |e|
        if h[xi] == nil
          h[xi] = {}
        end
        h[xi][vi] = e
        #output += "H at [#{xi}][#{vi}] = #{h[xi][vi]}<br>"
        vi += 1        
      end
      xi+= 1
      vi = 1
    end
    
    
    #for each row in data, 
    #insert points to ubp if email is unique and max_points is not reached for this user
    xi=0
    vi=1
    username = ""
    email = ""
    user_id = ""
    h.each do |row|
      #output += "row = #{row}<br>"
      row.each do |col|
        if xi>header_row
          if vi==username_column
            username = h[xi][vi].chomp
            #does user exist?
            if User.find_by_username(username) ==nil
              User.createUser(username)
            end
          end
          if vi==email_column
            unless is_email?(h[xi][vi])
              h[xi][vi] = {}
            end
            #has someone already submitted this email in this batch?:
            if unique_emails.has_value?(h[xi][vi])
              email = ""
            else 
              unique_emails[ue_i] = h[xi][vi]
              ue_i+=1
              email = h[xi][vi].chomp
              #is user supplying its own email address for points?:
              if User.find_by_email(email) != nil
                if User.find_by_email(email).username = username 
                  username = ""
                end
              end
            end
          end
        end #if xi>1
        vi+=1
      end #col
      xi+=1
      vi=1
      if username != "" && email != ""
        user_id = User.find_by_username(username).id
        #is this user already at max points?
        cba.each do |award|
          ubp = UserBoothPoint.find(:first, :conditions=>["conference_booth_award_id = 
            ? AND user_id = ?",award.id, user_id])
          if ubp ==nil
            new_ubp = UserBoothPoint.new
            new_ubp.conference_booth_award_id = award.id
            new_ubp.points = award.point_value
            new_ubp.guesses = 0
            new_ubp.user_id = user_id
            new_ubp.conference_id = conference_id
            new_ubp.conference_booth_id = 0
            begin
              new_ubp.save
              output += "Succeeded adding points for user #{username} for email address #{email}<br>"
            rescue
              output += "Failed adding points for user #{username} for email address #{email}<br>"
            end
            break #go on to the next row of list of user/emails
          end
        end
      end
    end #row
    flash[:notice] = output
  end

protected
  
  def do_upload_users2
  #experiemental method
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "upload_users"
      render(:action => "login")
      return
      
    end
    
    filename = "C:\\Documents and Settings\\hema.balaji\\Desktop\\1.csv"
    output = "<table border=1><tr>"
    CSV.open(filename,'r') do |row|
      row.each do |r|
        output+= "<td>#{r} </td>"
      end
      output+= "</tr><tr>"
    end
    output+="</table>"
    flash[:notice] = output
        
    #This does not work:
    #CSV.foreach(users)  do |L|
    #    output+= "row #{col} : #{L}<br>"
    #    col +=1
    #end    
  end
  
  
  def download_document

    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "download_document"
      render(:action => "login")
    end
    
  end


  def do_download_document
    
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "download_document"
      render(:action => "login")
    end
    
    id = params[:docid];
      
    if id == nil
      flash[:notice] = "Unable to find file by docid"
      return
    end
    
    begin
      doc = ConferenceBoothDocument.find(id)
    rescue
      flash[:notice] = "Unable to find document with id: #{id}"
      render 'error'
      return;
    end
    
    if doc == nil
       flash[:notice] = "Unable to find file by docid: #{id}"
       render 'error'
       return
    end
    
    send_data doc.data, :filename => doc.name, :type => "application/octet-stream", :disposition => "inline"
    
  end  


  def upload_document
  
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "upload_document"
      render(:action => "login")
    end
  
    @conferences = Conference.find(:all);
    
    @conference_booths = ConferenceBooth.find(:all);
  
  end


  def do_upload_document
    
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "upload_document"
      render(:action => "login")
    end

    tmp = {}
    
    tmp[:name] = params[:file][:name]
    tmp[:conference_booth_id] = params[:file][:conference_booth_id]
    tmp[:data] = params[:file][:data].read
     
    doc = ConferenceBoothDocument.new(tmp);
  
    if doc.save
             
       @nudocs = ConferenceBoothDocument.find(:all, :order => "id DESC", :limit => 1);
          
       send_data @nudocs[0].data, :filename => @nudocs[0].name, :type => "image/gif", :disposition => "inline"
      
    else
      flash[:notice] = "Unable to save file.";
      return
    end

  end


  def show_award_option_list
  
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:user_action] = "show_award_option_list"
      render(:action => "login")
    end
    
    @conference_booth_id = params['boothCode']
    @user_id = params['userId']
    
        
    if @conference_booth_id == nil
      flash[:notice] = "Query Parameters do not include the conference booth id.  Can't continue."
      return
    end
    
    if @user_id == nil
      flash[:notice] = "Query Parameters do not include the user id.  Can't continue."
      return
    end
  
    @awards = ConferenceBoothAward.find(:all, :conditions=>["conference_booth_id = ?", @conference_booth_id])
    
    if @awards == nil || @awards.length == 0
      flash[:notice] = "There are no awards provided for this booth."
    end
    
    logger.debug("Awards: #{@awards.length}")
    
    @user_awards = UserBoothPoint.find(:all, :conditions=>["conference_booth_id = ?", @conference_booth_id])
  
    @award_map = {}
    
    @user_awards.each do |ua| 
      @award_map[ua.conference_booth_award_id] = true
    end
  
  end


  def point_total_for_conference_booth(conference_booth_id)
    
    @conference_booths = ConferenceBoothAward.find(:all, :conditions=>["conference_booth_id = ?",conference_booth_id])
    
    total = 0
    
    @conference_booths.each do |cb|
      total += cb.point_value.to_i
    end
    return total
    
  end
  
  def point_total_for_user
  end
  
  def is_email?(str)
    r1 = Regexp.new('.+@.+\..+')
      unless r1.match(str) ==nil
        return true
      else
        return false
      end
    
  
  end
  
end
