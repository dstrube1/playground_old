class ReportController < ApplicationController
  
  require 'user_conference_record'
  require 'booth_conference_record'

  def index
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:controller] = "report"
      render(:action => "login_fail")
      return
    end
    
    @conferences = Conference.find(:all)
    @options = {}
    @back = ""

    if Vendor.find(:first, :conditions=>["user_id = ?",session[:user_id]]) == nil
      @options[:user_report] = "User Reports"
      @options[:booth_report] = "Booth Reports"
      @options[:booth_award_report] = "Users who got Award at Booth"
      @options[:user_award_report] = "Count of users who got awards at a booth"
      @back = "admin/admin_welcome"
    else
      @options[:show_user_award_report] = "Count of users who got awards at my booth"
      @back = "admin/vendor_welcome"
    end
    
    #@options = @options.sort_by{|value|value[0]}
  end

  
  def login_fail
  end


  def user_report
  
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:controller] = "report"
      render(:action => "login_fail")
      return
    end
    
    users = User.find(:all)

    @user_count = 0
    @user_point_totals = {}
    @goal = ConferencePrize.find(:first).total_points_required
    @highlight = "<b>"
    @unhighlight = "</b>"
    point_total = 0

    users.each do |user|
      @user_count +=1
      ubps = UserBoothPoint.find(:all, :conditions=>["user_id = ?",user.id])
      ubps.each do |ubp|
        point_total+=ubp.points
      end
      if point_total >= @goal
        user.username = "<h3>#{user.username}</h3>"
      end
      @user_point_totals[user.id]=[user.username,point_total]
      point_total=0
    end
    
    @user_point_totals = @user_point_totals.sort_by{|value|value[1][1]}
    @user_point_totals = @user_point_totals.reverse

  end
  
  
  def booth_report
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:controller] = "report"
      render(:action => "login_fail")
      return
    end
    
    booths = ConferenceBooth.find(:all)
    @booth_count = 0
    @booth_point_totals = {}
    point_total = 0
    
    booths.each do |booth|
      @booth_count += 1
      ubps = UserBoothPoint.find(:all, :conditions=>["conference_booth_id = ?",booth.id])
      ubps.each do |ubp|
        point_total+=ubp.points
        #render_text "#{ubp.points} points for booth #{booth.booth_id}"
      end
      #render_text "point total for booth id #{booth.booth_id} = #{point_total}"
      @booth_point_totals[booth.id]=[booth.booth.name,point_total]
      point_total=0
    end
    @booth_point_totals = @booth_point_totals.sort_by{|value|value[1][1]}
    @booth_point_totals = @booth_point_totals.reverse
  end  
  
  
  def booth_award_report
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:controller] = "report"
      render(:action => "login_fail")
      return
    end
    
    @booths= Booth.find(:all)
    @awards=Award.find(:all)
  end
  
  
  def show_booth_award_report
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:controller] = "report"
      render(:action => "login_fail")
      return
    end
    
    @results = {}
    booth_id = params[:report][:booth]
    @booth = Booth.find(booth_id).name
    award_id = params[:report][:award]
    @award = Award.find(award_id).name
    cb = ConferenceBooth.find(:first, :conditions=>["booth_id = ?",booth_id])
    if cb == nil
      render_text "The booth \"#{@booth}\" is not associated with a conference."
      return
    end
    cba= ConferenceBoothAward.find(:first, :conditions=>["conference_booth_id = ? and 
      award_id = ?", cb.id, award_id])
    if cba == nil
      render_text "The award \"#{@award}\" is not associated with booth \"#{@booth}\" at a conference."
      return
    end
    users = UserBoothPoint.find(:all, :conditions=>["conference_booth_id = ? and
    conference_booth_award_id = ?",cb.id, cba.id])
    if users.length ==0
      render_text "No users have achieved this award \"#{@award}\" at this booth \"#{@booth}\". "
      return
    end
    users.each do |user|
      @results[user.user_id] = User.find(user.user_id).username
    end
  end
  
  
  def user_award_report
    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:controller] = "report"
      render(:action => "login_fail")
      return
    end
    
    unless Vendor.find_by_user(session[:user_id]) == nil
      render(:action => "show_user_award_report")
    else
      @booths= Booth.find(:all)
    end
  end


  def show_user_award_report

    if session[:user_id] == nil 
      flash[:notice] = "You must login before you can access this page."
      session[:controller] = "report"
      render(:action => "login_fail")
      return
    end
    
    @output = {}
    count = 0
    user_id = session[:user_id]
    
    if Vendor.find_by_user(session[:user_id]) == nil #user is vendor
      booth_id = params[:report][:booth]
    else
      booth_id = Vendor.find_by_user(session[:user_id]).booth_id
    end
    
    @booth = Booth.find(booth_id).name
    
    cb_id = ConferenceBooth.find(:first, :conditions=>["booth_id = ?",booth_id]).id
    
    awards = Award.find(:all)
      
    awards.each do |award|
      cba = ConferenceBoothAward.find(:first, :conditions=>["conference_booth_id = ? AND
      award_id = ?", cb_id, award.id])
      cba_id = 0
      if cba !=nil 
        cba_id = cba.id
      end
      users = UserBoothPoint.find(:all, :conditions=>["conference_booth_award_id 
        = ? AND conference_booth_id = ?", cba_id, cb_id]) 
      
      users.each do |user|
       # @output += "<br>#{User.find(user.user_id).username}"
        count += 1
      end
      
      @output[award.name] = count
      
      count = 0
    end

  end
  
  
protected
  
  def customer_awards
  end
  
  def show_customer_awards

    #render(:action => "report/customer_award_report")
    flash[:notice] = "blah"
#    return
    
    conference = Conference.find(params['id'])

    records = UserBoothPoint.find(:all, :conditions=>["conference_id = ?", conference.id], :order=>"user_id ASC")
  
    logger.debug("User Records for conference #{conference.id}: #{records.length}")
  
    last_user_id = -1
    
    
    @user_records = []

    points = 0    
    
    
    
    records.each do |r|
    
      logger.debug("record:  user_id: #{r.user.id}, #{r.user.username}, #{r.points}")
    
      if r.user.id != last_user_id
      
        logger.debug("last_user_id: #{last_user_id}")
      
         if last_user_id != -1
           ucr = UserConferenceRecord.new( last_user_id, r.user.username, points )
           @user_records << ucr
         end
         
         last_user_id = r.user.id
         points = r.points
         
         
         
      else
        points += r.points
        
        logger.debug("points are: #{points}")
        
      end    
    
    end

    logger.debug("last user id is now: #{last_user_id}")
    
    r = records.last()

    logger.debug("last record is: #{r.user.username}")
    
    ucr = UserConferenceRecord.new( last_user_id, r.user.username, points)
    
    logger.debug("ucr.user_id = #{ucr.user_id} & last_user_id == #{last_user_id}")
    
    @user_records << ucr  

    logger.debug("user records: #{@user_records.length}")
  
    u = @user_records.first()
    
    logger.debug("user record: #{u.user_id}, #{u.name}, #{u.points}")
  
    render 'report/customer_award_report'
  
  end
  
  def show_booth_awards
  
    @booth_list = []
  
    conference = Conference.find(params['id'])

    conference_booths = ConferenceBooth.find(:all, :order=>"id ASC")

    conference_booths.each do |cb|
    
      user_records = UserBoothPoint.find(:all, :conditions=>["conference_booth_id = ?", cb.id])

      bcr = BoothConferenceRecord.new
      
      bcr.name = cb.booth.name
      bcr.id = cb.id
      
      user_records.each do |r|
        bcr.points += r.points
        bcr.visitors += 1      
      end      

      @booth_list << bcr
    
    end


    render 'report/booth_activity_report'
    
  end

end
