class IconController < ApplicationController



protected

  def show_icon
      
    @user_id = params['user_id']
    @booth_id = params['booth_id']
    @conference_id = params['conference_id']
    
    max_points = "???"
    
    if @user_id == nil
      return generate_blank_icon(max_points)
    end
    
    if @booth_id == nil
      return generate_blank_icon(max_points)
    end
    
    if @conference_id == nil
      return generate_blank_icon(max_points)
    end
    
    
    user = User.find(@user_id)
    
    if user == nil
      return generate_blank_icon(max_points)
    end
    
    # put the user into a session, so we can track them from page to page w/out
    # requiring us to send the userid everywhere. 
    #    
    session[:user_id] = user.id
    
    
    booth = Booth.find(@booth_id)
    
    if booth == nil
      return generate_blank_icon(max_points)
    end
    
    conference = Conference.find(@conference_id)
    
    if conference == nil
      return generate_blank_icon(max_points)
    end
    
    conference_prize = ConferencePrize.find(:first, :conditions=>["conference_id = ?", conference.id])
    
    if conference_prize == nil
      return generate_blank_icon(max_points)
    end
    
    conference_booth = ConferenceBooth.find(:first, :conditions=>["booth_id = ? AND conference_id = ?", booth.id, conference.id])

    if conference_booth == nil
      return generate_blank_icon(conference_prize.total_points_required)
    end

    prize = conference_prize.prize
    
    user_points = PointsCalculator.sum_user_points(conference, user)

    @points_remaining = conference_prize.total_points_required - user_points

    if @points_remaining < 0
      @points_remaining = 0
    end

    @form_url = "http://localhost:3000/main/show_award_option_list?conference_booth_id=#{conference_booth.id}&user_id=#{user.id}"

    if @points_remaining == 0
      @image_url = prize.won_image_url
    else
      @image_url = prize.image_url
    end

    render "pages/icon.rhtml"
      
  end

  def generate_blank_icon(points)
      logger.error("Unable to find critical element for icon.  Creating blank icon")    
    
    
  end





end
