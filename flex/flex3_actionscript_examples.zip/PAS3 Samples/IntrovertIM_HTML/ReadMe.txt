Notes for the IntrovertIM_HTML example:

Flex version:
The source code for this example includes the HTML document with JavaScript code that is used to complete the application, in the "html-template" folder.  That is the folder where Flex Builder puts its own HTML template. By default Flex Builder overwrites the html-template folder's contents, so to run this example you will want to keep a separate copy of the html-template folder and paste it in once Flex Builder has created the files in the "html-template" folder.

Flash version:
The HTML page containing the JavaScript for this example is in the "html-flash" folder. This is the folder where the Flash is set to publish the SWF. The FLA file's publish settings are set to not publish an HTML page by default, because the new page would override the predefined HTML page.
To test the application, publish the Flash movie, then open the IntrovertIMApp.html page from the "html-flash" folder in your web browser.
In order to test the IntrovertIM HTML application on your hard drive, you will need to designate the "html-flash" folder as a trusted location; otherwise you will see a security error when you view the page in a browser.