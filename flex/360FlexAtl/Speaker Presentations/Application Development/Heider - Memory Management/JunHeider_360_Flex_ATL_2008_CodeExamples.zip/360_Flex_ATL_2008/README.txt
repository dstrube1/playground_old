General Disclaimer and FYI:

1. I had no sleep last night.  If you see errors in the code, I apologizes in advance...

2. Although these are good test apps to learn memory management and optimization concepts, they should not be construed as 100% best practice...iow, lack of ASDoc comments, not completely optimized, etc.

3. 360_CollectionInstantiation_GOOD and 360_CollectionInstantiation_BAD are both AIR apps.  Basically you get a folder of images, run each of them and point them to the folder to see the difference between Tile/Repeater and TileList

4. 360_GettingData is a ColdFusion8 remoting app...there's also a readme in there regarding the datasource...if you don't have ColdFusion 8 you can download the developer edition from Adobe's site.

5. The _Performance_ ones are ready made examples to compare/contrast different coding conventions.  You can play with the number of loops to see how it affects the performance results...highly recommend using REDbug Log tab with it.

6. If you have any questions, feel free to shoot me an email. jun@realeyes.com

Have fun!

-Jun