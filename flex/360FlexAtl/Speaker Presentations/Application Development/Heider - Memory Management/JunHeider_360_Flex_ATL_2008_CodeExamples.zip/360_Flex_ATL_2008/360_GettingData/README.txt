This project was configured to run on ColdFusion8

The path from the cfwebroot is: /360_MyCFRemoting-debug/

You will need to set up an MS Access datasource called USDA that points to:
{cfwebroot}\360_MyCFRemoting-debug\db\FNDDS2.mdb


==========================================================================

Database being used: http://www.ars.usda.gov/Services/docs.htm?docid=12068

USDA Food and Nutrient Database for Dietary Studies, 2.0. 2006. 
Beltsville, MD: Agricultural Research Service, 
Food Surveys Research Group.


