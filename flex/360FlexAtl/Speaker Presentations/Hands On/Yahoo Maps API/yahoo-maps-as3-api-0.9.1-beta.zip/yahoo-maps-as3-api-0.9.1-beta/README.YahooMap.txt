Yahoo! Maps API (AS3) Release Notes

Drop the YahooMap.swc file into your /libs/ folder in Flex Builder 3. 

=====

Version 0.9.1  [2008/02/25] zachg
	- New constructor syntax. (see below)
	- Polyline overlay now has a geodesic flag. 
	- aerial copyright duplication fixed
	- Dynamic map insertion issue fixed
	- Marker maxZoom & minZoom properties fixed
	- Event.MOUSE_LEAVE event stops panning
	- Overlay.invalidate() now Overlay.destroy()
	- YahooMap MouseEvents now work much better 
	- Fixed issue with the latlon property in YahooMap mouse events being incorrect in Flex apps
	- local search dphone & phone properties
	- local search categories/rating filters fixed
	- setZoomRange / getZoomRange returned incorrect values. 

	(NEW) YahooMap constructor change:
	To create a YahooMap object, you must now call YahooMap.init() and pass your app-id, width and height, rather than in the constructor

	Example:
	_yahooMap = new YahooMap();
	_yahooMap.addEventListener(YahooMapEvent.MAP_INITIALIZE, handleMapInitialize, false, 0, true);
	_yahooMap.init(APP_ID, this.stage.stageWidth, this.stage.stageHeight);


Version 0.9.0  [2008/02/11] zachg
- Initial release. See http://developer.yahoo.com/flash/maps/