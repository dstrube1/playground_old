function Settings() {
	this.$init();
}

Settings.prototype = {
	$init : function() {
	},
	
	/**
	 * Read the whole content of the setting file
	 */
	_readSettingsFile: function() {
		var sourceFile = air.File.applicationStorageDirectory.resolvePath(Settings.Constants.SETTINGS_FILE);
		var sourceStream = new air.FileStream();
		var content = false;

		try {
			sourceStream.open(sourceFile, air.FileMode.READ);
			content = sourceStream.readUTFBytes(sourceStream.bytesAvailable);
			sourceStream.close();
		} catch (e) {}

		return content;
	},
	
	/**
	 * Overwrite the settings file content with the given content
	 */
	_saveSettingsFile: function(content) {
		var destinationFile = air.File.applicationStorageDirectory.resolvePath(Settings.Constants.SETTINGS_FILE);
		var destinationStream = new air.FileStream();

		try {
			destinationStream.open(destinationFile, air.FileMode.WRITE);
			destinationStream.writeUTFBytes(content);
			destinationStream.close();
		} catch(e) {}
		
	},
	
	/**
	 * Creates an empty settings file if there is no one on disc
	 */
	_getOrCreateEmptySettings: function() {
		var content = this._readSettingsFile();
		if (content != false)
			return content;
		doc = (new DOMParser()).parseFromString(Settings.Constants.STR_XML_DECL + Settings.Constants.STR_SETTINGS, 'text/xml');
		if(!doc || doc.documentElement.nodeName == 'parsererror') {
			return false;
		}
		var root = doc.documentElement || doc;
		var pollTime = doc.createElement (Settings.Constants.STR_POLLTIME);
		pollTime.setAttribute('value', Settings.Constants.DEFAULT_POLLTIME);
		root.appendChild(pollTime);
		var minToTray = doc.createElement (Settings.Constants.STR_MINIMIZE_TRAY);
		minToTray.setAttribute('value', Settings.Constants.DEFAULT_MINTRAY);
		root.appendChild(minToTray);
      	var s = new XMLSerializer();
      	var serializedCont = s.serializeToString(doc);
      	this._saveSettingsFile(serializedCont);
      	return serializedCont;
	},
	
	/**
	 * Reads the polling time from the settings file
	 */
	getPollingTime: function() {
		var content = this._getOrCreateEmptySettings();
		if (content == false) {
			return Settings.Constants.DEFAULT_POLLTIME;
		}
    	
    	var doc = (new DOMParser()).parseFromString(content, 'text/xml');
    	var pollTime = doc.getElementsByTagName(Settings.Constants.STR_POLLTIME);
    	return pollTime[0].getAttribute('value');
    	
	},
	
	/**
	 * Save the polling time to settings file
	 */
	setPollingTime: function(time) {
		var content = this._getOrCreateEmptySettings();
		if (content == false) {
			return;
		}
  		var doc = (new DOMParser()).parseFromString(content, 'text/xml');
    	var pollTime = doc.getElementsByTagName(Settings.Constants.STR_POLLTIME);
    	pollTime[0].setAttribute('value', time);

    	var s = new XMLSerializer();
    	var serializedCont = s.serializeToString(doc);
    	this._saveSettingsFile(serializedCont);	
	},
	
	/**
	 * Get the minimize to tray value from the settings file
	 */
	getMinimizeTray: function() {
		var content = this._getOrCreateEmptySettings();
		if (content == false) {
			return Settings.Constants.DEFAULT_POLLTIME;
		}
    	
    	var doc = (new DOMParser()).parseFromString(content, 'text/xml');
    	var minimizeTray = doc.getElementsByTagName(Settings.Constants.STR_MINIMIZE_TRAY);
    	return minimizeTray[0].getAttribute('value') == "true";
	},
	
	/**
	 * Save the minimize to tray value to the settings file
	 */
	setMinimizeTray: function(minimize) {
		var content = this._getOrCreateEmptySettings();
		if (content == false) {
			return;
		}
  		var doc = (new DOMParser()).parseFromString(content, 'text/xml');
    	var minimizeTray = doc.getElementsByTagName(Settings.Constants.STR_MINIMIZE_TRAY);
    	minimizeTray[0].setAttribute('value', minimize);

    	var s = new XMLSerializer();
    	var serializedCont = s.serializeToString(doc);
    	this._saveSettingsFile(serializedCont);	
	},	
	
}

/**
 * Settings constants
 */
Settings.Constants = {
	SETTINGS_FILE:		'settings.xml',
	STR_XML_DECL: 		'<?xml version="1.0" encoding="iso-8859-1"?>\n',
	STR_SETTINGS: 		'<settings></settings>',
	STR_POLLTIME:		'pollTime',
	STR_MINIMIZE_TRAY:	'minimizeToTray',
	DEFAULT_POLLTIME:	1,
	DEFAULT_MINTRAY:	false
}