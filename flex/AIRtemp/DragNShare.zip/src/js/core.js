/*
 * application name space
 */
var dnshare = {};

/**
 * Callback to be fired after the page DOM has loaded.
 */
dnshare.DOMReady = function() {
	dnshare.notifyOnLoadAllListeners();
}

/**
 * Adds a listener to be notified after application content completely loads.
 * @param funcListener {Function}	
 * 				The listener to be added.
 */
dnshare.addAllLoadedListener = function(funcListener) {
	dnshare.allLoadedListeners[funcListener] = funcListener;
}

/**
 * Removes an existing listener 
 * @param funcListener {Function}	
 * 		The existing listener to be removed.
 * @see dnshare.addAllLoadedListener(funcListener)
 */
dnshare.removeAllLoadedListener = function(funcListener) {
	dnshare.allLoadedListeners[funcListener] = null;
	delete dnshare.allLoadedListeners[funcListener];
}

/**
 * Notifies all registered listeners interested in having the page content 
 * completely loaded.
 * @private
 * @static
 */
dnshare.notifyOnLoadAllListeners = function() {
	for(listener in dnshare.allLoadedListeners) {
		dnshare.allLoadedListeners[listener].call();
	}
}

/**
 * Hash to hold all registered listeners
 * @private
 */
dnshare.allLoadedListeners = {};