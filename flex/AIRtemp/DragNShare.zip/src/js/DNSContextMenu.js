function DNSContextMenu() {
	this.$init();
}

DNSContextMenu.prototype = {
	$init : function() {
		var _self = this;
		var menu = new air.NativeMenu();
		var openMenu = new air.NativeMenuItem("Open in Google Documents");
		openMenu.addEventListener(air.Event.SELECT, function(ev) {_self.openDocument() });
		menu.addItem(openMenu);
		
    	this.menu = menu;
	},
	
	showMenu: function(x, y, url) {
		this.url = url;
		this.menu.display(nativeWindow.stage, x, y);
	},
	
	openDocument: function() {
		if (!this.url) {
			return;
		}
		air.navigateToURL(new air.URLRequest(this.url));
	},
	
	saeDocument: function() {
		if (!this.url) {
			return;
		}
		alert("Save: " + this.url);
	}
};