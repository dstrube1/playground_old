function DocsUploaderSystem() {
	this.$init();
}
DocsUploaderSystem.prototype = {
	$init: function() {
		this.file = null;
		var _self = this;
		this.events = {
			selectFileSucces: [
				function(e){
					if(e.length){
					_self.file = e[0];
						if(e[0].size==0){
							_self._notifyEventListeners('uploadStatus', {state:'disableUpload'});
							alert('Empty files cannot be uploaded to Google!');
						}
						else
					_self._notifyEventListeners('uploadStatus', {state:'enableUpload', fileName:_self.file.name});
					}else
						_self._notifyEventListeners('uploadStatus', {state:'disableUpload'});
				}
			],
			selectFileFailure: [
				function (e){
					_self._notifyEventListeners('uploadStatus', {state:'disableUpload'});

				}
			],
			uploadStatus: []
		}
		
		this.authToken = null;
		
	},
	
	registerToken : function(token){
		this.authToken = token;
	
	},
	
	dropFiles: function(fileList){
		var files = [];
		if(!fileList)return;
		for(var z=fileList.length-1;z>=0;z--){

			var file = new air.File(fileList[z].nativePath);
			var ext = file.extension.toLowerCase();
			if(DocsUploaderSystem.mime_types[ext])
				files.push(file);
			
		}
			
		if(this.authToken)
			this._notifyEventListeners('selectFileSucces', files);
	}, 
	
	uploadFiles: function(title){
		var loader = new air.URLLoader();
		var _self = this;
					loader.addEventListener(air.ProgressEvent.PROGRESS , function(e){
						_self._notifyEventListeners('uploadStatus', {state:'progress',bytesTotal:e.bytesTotal, bytesLoaded:e.bytesLoaded});
					});
					loader.addEventListener(air.Event.COMPLETE, function(e){
						if(loader.data.substr(0, 4)=="<?xm")
						_self._notifyEventListeners('uploadStatus', {state:'complete'});
						else {
							air.trace('Invalid response: ' + loader.data);
							_self._notifyEventListeners('uploadStatus', {state:'error', message: 'Unable to upload this document. Please check if it is a valid document.'});
						}								
					});
					
					loader.addEventListener(air.IOErrorEvent.IO_ERROR , function (e){
						_self._notifyEventListeners('uploadStatus', {state:'error', message: e.text});								
					});
	
			this._notifyEventListeners('uploadStatus', {state:'start'});
			loader.load(this._buildUploadRequest(title, this.file));		
	
	},
	
	browseToUploadFiles: function() {
		this._showBrowseForFileDialog(false);
	},
	
	addEventListener : function(strEventType, fnCallback) {
		this.events[strEventType].push(fnCallback);
	},

	removeEventListener : function(strEventType, fnCallback) {
		for (var i=0; i<this.events[strEventType].length, i++;) {
			if(this.events[strEventType][i] === fnCallback) {
				this.events[strEventType][i] = function(){};
				var deleted = this.events[strEventType][i];
				this.events[strEventType].sort ( function(a, b) {
					return (a === deleted)? 1: (b !== deleted)? -1: 0;
				});
				this.events[strEventType].pop();
			}
		}
	},
	
	_notifyEventListeners : function(strEventType, responseObj) {
		var listeners = this.events[strEventType];
		for(var i=0; i<listeners.length; i++) {
			listeners[i](responseObj);
		}
	},
	
	_makeFileFilter: function ( strName, arrExtensions) {
		return new air.FileFilter (strName, '*.'+arrExtensions.join(';*.'));
	},
	
	_makeFilterTitleExts : function(types){
		return " ("+types.join('; ')+")";	
	},
	
	_makeDefaultFilters: function () {
		var f = [];
		with (DocsUploaderSystem.defaults) {
			f.push( new air.FileFilter (ALL_DOCUMENTS+this._makeFilterTitleExts(BOTH_TYPES), BOTH_TYPES.join(';')));
			f.push( new air.FileFilter (DOCUMENTS_ONLY+this._makeFilterTitleExts(DOCUMENT_TYPE), DOCUMENT_TYPE.join(';')));
			f.push( new air.FileFilter (SPREADHEET_ONLY+this._makeFilterTitleExts(SPREADSHEET_TYPE), SPREADSHEET_TYPE.join(';')));
			f.push( new air.FileFilter (PRESENTATION_ONLY+this._makeFilterTitleExts(PRESENTATION_TYPE), PRESENTATION_TYPE.join(';')));
		}
		var ret = f;
		return ret;
	},
	
	_makeDefaultTitle: function( bMultiple ) {
		with (DocsUploaderSystem.defaults) {
			return bMultiple? SELECT_MULTIPLE: SELECT_SINGLE;
		}
	},
	
	_showBrowseForFileDialog: function (bMultiple, sTitle, arrFilters) {
		var title = sTitle || this._makeDefaultTitle (bMultiple);
		var filters = arrFilters || this._makeDefaultFilters();
		var f = new air.File();
		var _self = this;
		f.addEventListener(air.Event.SELECT, function(oEvent) {
			_self._notifyEventListeners('selectFileSucces', [oEvent.target]);
		});
		f.addEventListener(air.FileListEvent.SELECT_MULTIPLE, function(oEvent) {
			_self._notifyEventListeners('selectFileSucces', oEvent.files);
		});
		try {
			if ( bMultiple ) {
				f.browseForOpenMultiple ( title, filters );
			} else {
				f.browseForOpen ( title, filters );
			}
		} catch (e) {
			this._notifyEventListeners( 'selectFileFailure', e);
		}
	},
	
	_buildUploadRequest: function(title, file){
		var ext = file.extension.toLowerCase();
		

		title = title.replace(/&/g, "&amp;").replace(/</g, "&lt;");
	
		var mime_type = DocsUploaderSystem.mime_types[ext];
		var atom_type = DocsUploaderSystem.atom_types[ext];
		
		if(mime_type==null) mime_type = "application/octet-stream";
		if(atom_type==null) atom_type = "document";
		
		
		var requestMeta = this._makeArgs({TITLE: title, TYPE: atom_type }, 
								DocsUploaderSystem.templates.UPLOAD_REQUEST );
		
		var request = new air.URLRequest('http://docs.google.com/feeds/documents/private/full');
	
		var endPart = "END_OF_PART___ADOBE_AIR_DELIMITER_FOR_MIMETYPES";
		
		var fileStream = new air.FileStream();
		fileStream.open(file, air.FileMode.READ);
		var fileContents = new air.ByteArray();
		fileStream.readBytes(fileContents, 0, file.size);
		fileStream.close();
		
		request.method='POST';
		var buffer = new air.ByteArray();
		
		if(ext.substr(0,3)!="htm"){
	
			buffer.writeUTFBytes("Media multipart posting\r\n--"+endPart+"\r\nContent-Type: application/atom+xml\r\n\r\n"+requestMeta);
			buffer.writeUTFBytes("\r\n--"+endPart+"\r\nContent-Type: "+mime_type+";\r\n");
			
			//	buffer.writeUTFBytes('charset="us-ascii"\r\nContent-Transfer-Encoding: quoted-printable\r\n');
			
			
			buffer.writeUTFBytes("\r\n");
	
		buffer.writeBytes(fileContents, 0, fileContents.length);
			var ctype='';
			
			if("txt,csv".indexOf(ext)>-1){
				buffer.writeUTFBytes('\r\n--'+endPart+'--\r\n');
				ctype='type="text/plain"; ';
		
			}
			else
		buffer.writeUTFBytes('--'+endPart+'--\r\n');

		request.requestHeaders = [new air.URLRequestHeader("Slug", file.name),
				new air.URLRequestHeader("Authorization", 'GoogleLogin auth=' +this.authToken),
					new air.URLRequestHeader("Content-Type", 'multipart/related; '+ctype+'boundary='+endPart),
				new air.URLRequestHeader("MIME-version", "1.0")
				];
		}
		request.data = buffer;
		return request;
	},
	
	_makeArgs: function (oArgs, template) {
		var requestArgs = template;
		for (fieldName in oArgs) {
					var pattern = DocsUploaderSystem.patterns.
						makeCustomPlaceholder(fieldName);
					var value = oArgs[fieldName];
					requestArgs = requestArgs.replace(pattern, value);
		}
		return requestArgs;
	}
	
}

DocsUploaderSystem.defaults = {
	SELECT_SINGLE:		'Select File To Upload',
	SELECT_MULTIPLE:	'Select Files To Upload',
	DOCUMENTS_ONLY:		'Text Documents',
	SPREADHEET_ONLY:	'Spreadsheets',
	PRESENTATION_ONLY:	'Presentation',
	ALL_DOCUMENTS:		'All supported documents',
	DOCUMENT_TYPE:		['*.doc', '*.rtf', '*.odt', '*.sxw', '*.txt'],
	SPREADSHEET_TYPE:	['*.xls', '*.csv', '*.ods'],
	BOTH_TYPES:			['*.doc', '*.txt', '*.rtf', '*.odt', '*.sxw', '*.xls', '*.csv', '*.ods', '*.pps', '*.ppt', '*.txt'],
	PRESENTATION_TYPE:	['*.pps', '*.ppt']
}

DocsUploaderSystem.templates = {
	UPLOAD_REQUEST: "<?xml version='1.0' encoding='UTF-8'?>\r\n\
<atom:entry xmlns:atom=\"http://www.w3.org/2005/Atom\">\r\n\
  <atom:category scheme=\"http://schemas.google.com/g/2005#kind\" term=\"http://schemas.google.com/docs/2007#%TYPE%\" /> \r\n\
  <atom:title>%TITLE%</atom:title> \r\n\
</atom:entry>"
}

DocsUploaderSystem.patterns = {
	makeCustomPlaceholder: function(custStr, bGlobal) {
		return new RegExp("%"+custStr+"%", (bGlobal? "g": ""));
	}
}


DocsUploaderSystem.mime_types = {
			//plain text
			txt:"text/plain",
			
			csv:"text/comma-separated-values",
			//presentation
			pps:"application/vnd.ms-powerpoint",
			ppt:"application/vnd.ms-powerpoint",
			//rich text format
			rtf:"application/rtf",
			doc:"application/msword",
			odt:"application/vnd.oasis.opendocument.text",
			sxw:"application/vnd.sun.xml.writer",
			//spreadsheets
			xls:"application/vnd.ms-excel",
			ods:"application/vnd.oasis.opendocument.spreadsheet",
		};

DocsUploaderSystem.atom_types = {
			csv: 'spreadsheet',
			xls: 'spreadsheet',
			ods: 'spreadsheet',
			
			txt: 'document',
			doc: 'document',
			rtf: 'document',
			odt: 'document',
			sxw: 'document',			
			
			pps: 'presentation',
			ppt: 'presentation',
			
			
		};