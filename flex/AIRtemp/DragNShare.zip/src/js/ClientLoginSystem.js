function ClientLoginSystem() {
	this._init();
}
ClientLoginSystem.prototype = {
	_init: function() {
		this.$ = YAHOO.util.Dom.get;
		this.$fparser	   = null;
		this.$refreshTimeout = null;
		this.usernamefield = this._getUserNameField();
		this.passwordField = this._getPasswordField();
		this.captchaField  = this._getCAPTCHAfield();
		this.loginButton   = this._getLoginButton();
		this.mainDisplay   = this._getMainDisplay();
		this.systemState   = ClientLoginSystem.STATE_LOGIN;
		this._updateAppLayout();
		this._linkControlls();
	},
	

	_linkControlls: function() {
		var _self = this;
		YAHOO.util.Event.addListener (this.loginButton, 'click', function() {
			_self.doLogin();	
		});
		YAHOO.util.Event.addListener ("logOutButton", 'click', function() {
			_self.doLogout();	
		});
	},
	
	_saveCredentials: function() {
		var sCredentials = 'user=' +
			encodeURIComponent(this.usernamefield.value) +
			'&pass=' +
			encodeURIComponent(this.passwordField.value);
		saveCredentials(sCredentials);
	},
	
	_destroyCredentials: function () {
		destroyCredentials();
		HTTPRequestSystem.destroyToken();
	},
	
	
	_makeControllsAvailable: function () {
		this.usernamefield.value = "@gmail.com";
		this.usernamefield.disabled = false;
		this.passwordField.value = "";
		this.passwordField.disabled = false;
		this.captchaField.value = "";
		this.captchaField.disabled = false;
		this.loginButton.disabled = false;
		this.$("rememberMeCheck").checked = false;
		this.$("rememberMeCheck").disabled = false;
	},
	
	_makeControllsUnavailable: function () {
		this.usernamefield.disabled = true;
		this.passwordField.disabled = true;
		this.captchaField.disabled = true;
		this.loginButton.disabled = true;
		this.$("rememberMeCheck").disabled = true;
	},
	
	doLogin: function() {
		if(this.systemState != ClientLoginSystem.STATE_OPERATE) {
			switch (this.systemState) {
				case ClientLoginSystem.STATE_LOGIN:
					this._makeInitialRequest();
					break;
				case ClientLoginSystem.STATE_CAPTCHA:
					this._makeSubsequentRequest();
					break;
			}
		}
	},
	
	doLogout: function() {
		this._destroyCredentials();
		this.systemState = ClientLoginSystem.STATE_LOGIN;
		this._updateAppLayout();
	},
	
	_getMainDisplay: function() {
		return this.$('mainDisplay');
	},
	
	_getUserNameField: function() {
		return this.$('usernameField');
	},
	
	_getPasswordField: function() {
		return this.$('passwordField');
	},
	
	_getCAPTCHAfield: function() {
		return this.$('captchaField');
		
	},
	
	_getLoginButton: function() {
		return this.$('authenticateButton');
	},


	_makeSubsequentRequest: function() {
		if (this.usernamefield.value && this.passwordField.value && 
			this.captchaField) {
			if (ClientLoginSystem.checkPatterns.validGMailAddress.
				test(this.usernamefield.value)) 
			{
				this._makeControllsUnavailable();
				var _self = this;
				var reqsys = new HTTPRequestSystem();
				reqsys.addEventListener("requestSucceeded", 
					function(response) { 
						_self._processLoginSuccess(response);
				});
				reqsys.addEventListener("requestFailed", 
					function(response) {
						_self._processLoginFailure(response);
					});
				reqsys.attemptLogin ({
					"USERNAME": this.usernamefield.value,
					"USERPASS": this.passwordField.value,
					"LOGINTOKEN": null, // 'HTTPRequestSystem' will take care
					"LOGINCAPTCHA": this.captchaField.value
				});
				return;
			}
		}
		this._showMessage(ClientLoginSystem.messages.BadAuthentication);
	},
	
	_makeInitialRequest: function() {
		if (this.usernamefield.value && this.passwordField.value) {
			if (ClientLoginSystem.checkPatterns.validGMailAddress.
				test(this.usernamefield.value)) 
			{
				this._makeControllsUnavailable();
				var _self = this;
				var reqsys = new HTTPRequestSystem();
				reqsys.addEventListener("requestSucceeded", 
					function(response) { 
						_self._processLoginSuccess(response);
				});
				reqsys.addEventListener("requestFailed", 
					function(response) {
						_self._processLoginFailure(response);
					});
				reqsys.attemptLogin ({
					"USERNAME": this.usernamefield.value,
					"USERPASS": this.passwordField.value
				});
				return;
			}
		}
		this._showMessage(ClientLoginSystem.messages.BadAuthentication);
	},
	
	_processLoginSuccess: function( oResponse ) {
		this._grabToken ( oResponse.responseText );
		this.systemState = ClientLoginSystem.STATE_OPERATE;
		this._updateAppLayout();
		this.refreshDocs();
		// save credentials if user so choosed
		if(this.$('rememberMeCheck').checked) {
			this._saveCredentials();
		}
	},


	refreshDocs : function(fromTimeout){
		
		if(!fromTimeout&&this.$refreshTimeout){
			clearTimeout(this.$refreshTimeout);
			this.$refreshTimeout = null;
		}
		
		var _self = this;
		var reqsys = new HTTPRequestSystem();
			reqsys.addEventListener ("requestSucceeded", 
				function(response) {
					_self.$fparser = new DocsFeedParser();
					_self.$fparser.updateDocsList (response);
					_self._setupNextRefresh();
				});
					
			reqsys.addEventListener ("requestFailed",
				function(){
					_self._setupNextRefresh();
				});
			
			reqsys.getDocs();

		
	},
	
	_processLoginFailure : function( oResponse ) {
		var match = oResponse.responseText.match(/Error=([\w]*)/);
		var respCode = match? match[1]: null;
		switch (respCode) {
			case 'BadAuthentication':
				// put system into captcha login
				this.systemState = ClientLoginSystem.STATE_LOGIN;
				this._updateAppLayout();
				this._showMessage (ClientLoginSystem.messages.BadAuthentication);
				this.usernamefield.value = "";
				this.passwordField.value = "";
				this.captchaField.value = "";
				break;
			case 'NotVerified':
				this._showMessage (ClientLoginSystem.messages.NotVerified);
				break;
			case 'TermsNotAgreed':
				this._showMessage (ClientLoginSystem.messages.TermsNotAgreed);
				break;
			case 'CaptchaRequired':
				// put system into captcha state
				this.systemState = ClientLoginSystem.STATE_CAPTCHA;
				// show the captcha controls and image on the page				
				this._updateAppLayout();
				var match = oResponse.responseText.match(/CaptchaUrl=([^\n]*)/);
				var url = match? match[1]: null;
				this._showCaptchaImage(url);
				// show the standard, 'bad authentication' error messages
				this._showMessage (ClientLoginSystem.messages.BadAuthentication);
				this.usernamefield.value = "";
				this.passwordField.value = "";
				this.captchaField.value = "";
				break;
			case 'AccountDeleted':
				this._showMessage (ClientLoginSystem.messages.AccountDeleted);
				break;
			case 'AccountDisabled':
				this._showMessage (ClientLoginSystem.messages.AccountDisabled);
				break;
			case 'ServiceDisabled':
				this._showMessage (ClientLoginSystem.messages.ServiceDisabled);
				break;
			case 'ServiceUnavailable':
				this._showMessage (ClientLoginSystem.messages.ServiceUnavailable);
				break;
			case 'Unknown':
			default:
				this._showMessage (ClientLoginSystem.messages.Unknown);
		}
	},
	
	_showCaptchaImage: function( url ) {
		url = ClientLoginSystem.urls.GoogleAccounts + url;
		this.$(captchaImage).src = url;
	},
	
	_showMessage : function ( MSG ) {
		this.$('messageArea').innerHTML = MSG;
	},
	
	_grabToken: function( gResponse ) {
		var match = gResponse.match(ClientLoginSystem.checkPatterns.authToken);
		if(match) {
			var token = match[1];
			HTTPRequestSystem.registerToken(token);
		}
	},
	
	_setupNextRefresh: function(){
		var _self = this;
		this.$refreshTimeout = setTimeout( function(){
			_self.refreshDocs(true)
		}, dnshare.settings.getPollTime() * 60000);
	},
	
	_updateAppLayout: function() {
		switch (this.systemState) {
			case ClientLoginSystem.STATE_LOGIN:
				if(this.$refreshTimeout){
					clearTimeout(this.$refreshTimeout);
				}
				YAHOO.util.Dom.removeClass ("controls", "captcha");
				this._hideAllModules();
				this._showModule(ClientLoginSystem.modules[0]);
				this._showModule(ClientLoginSystem.modules[4]);
				// force redraw (bug on Win32 in M5):
				this.$('mainDisplay').style.display = "none";
				var _self = this;
				window.setTimeout(function(){
					_self.$('mainDisplay').style.display = "block";
				}, 1);
				this._makeControllsAvailable();
				this._showMessage(ClientLoginSystem.messages.DefaultMessage);
				break;
			case ClientLoginSystem.STATE_CAPTCHA:
				YAHOO.util.Dom.addClass ("controls", "captcha");
				// force redraw (bug on Win32 in M5):
				this.$('mainDisplay').style.display = "none";
				var _self = this;
				window.setTimeout(function(){
					_self.$('mainDisplay').style.display = "block";
				}, 1);
				this._makeControllsAvailable();
				break;
			case ClientLoginSystem.STATE_OPERATE:
				this._setupNextRefresh();				
				this._hideAllModules();
				this.$("userNameText").innerHTML = this.usernamefield.value;
				this._showModule(ClientLoginSystem.modules[1]);
				this._showModule(ClientLoginSystem.modules[2]);
				this._showModule(ClientLoginSystem.modules[3]);
				this._showModule(ClientLoginSystem.modules[4]);
				break;
		}
	},
	
	_hideAllModules: function() {
		for(var i=0; i<ClientLoginSystem.modules.length; i++) {
			var modID = ClientLoginSystem.modules[i];
			this._hideModule( modID );
		}
	},
	
	_showModule: function( strModID ) {
		this.$(strModID).style.display = "block";
	},
	
	_hideModule: function( strModID ) {
		this.$(strModID).style.display = "none";
	}
	
}
ClientLoginSystem.STATE_LOGIN   = 0x1;
ClientLoginSystem.STATE_OPERATE = 0x2;
ClientLoginSystem.STATE_CAPTCHA = 0x4;
ClientLoginSystem.checkPatterns = {
	validGMailAddress: /[\w\.-_]*\@\gmail\.com$/,
	authToken: /Auth=(.*)/
}
ClientLoginSystem.modules = [
	"need_to_login_module",
	"already_logged_in_module",
	"documents_module",
	"settings_module",
	"about_module",
	"loading_screen_module"
];

ClientLoginSystem.urls = {
	GoogleAccounts: "http://www.google.com/accounts/"
}
ClientLoginSystem.messages = {
	DefaultMessage:'\
        	<p class="textDescription">In order to access your\
        		<em>Google Docs</em> account you must first\
        		authenticate using your Google account\
        		credentials.\
    		</p>',
	BadAuthentication: '\
			<p class="textDescription error">\
				Cannot log you into your Google account using the\
				credentials you provided.\
			</p>\
			<p class="textDescription">\
				Please make sure you correctly provide your full <em>GMail\
				address</em> as <em>username</em>, and its associated\
				<em>password</em>.\
			</p>',
	NotVerified: '\
			<p class="textDescription error">\
				Your account email address has not been verified yet.\
			</p>\
			<p class="textDescription">\
				You should login into your Google Account using your browser\
				and confirm your email address.\
			</p>',
	TermsNotAgreed: '\
			<p class="textDescription error">\
				You have not agreed to the terms of Google service.\
			</p>\
			<p class="textDescription">\
				You should login into your Google Account using your browser\
				and check the <em>I agree</em>checkbox.\
			</p>',
	AccountDeleted: '\
			<p class="textDescription error">\
				Google has deleted your account.\
			</p>\
			<p class="textDescription">\
				You may want to contact Google and ask for more details.\
			</p>',
	AccountDisabled: '\
			<p class="textDescription error">\
				Google has disabled your account.\
			</p>\
			<p class="textDescription">\
				You may want to contact Google and ask for more details.\
			</p>',
	ServiceDisabled: '\
			<p class="textDescription error">\
				The <em>Google docs</em> service is disabled.\
			</p>\
			<p class="textDescription">\
				You may want to contact Google and ask for more details.\
			</p>',
	ServiceUnavailable: '\
			<p class="textDescription error">\
				The <em>Google docs</em> service is temporarely unavailable.\
			</p>\
			<p class="textDescription">\
				Try to connect later, or you may want to contact Google and\
				ask for more details.\
			</p>',
	Unknown: '\
			<p class="textDescription error">\
				The <em>Google Docs</em> service has encountered an unknown\
				error.\
			</p>\
			<p class="textDescription">\
				You should try to connect again in a few moments. If this error\
				persists, you may want to contact Google.\
			</p>'
}