
SELECT* FROm CampaignAdTitleMapping catm
JOIN CampaignAdCategory cac ON cac.AdTitleMappingID = catm.AdTitleMappingID
	AND cac.CampaignID = catm.CampaignID
WHERE SEID = 84
AND ImageID IN (4692,4691)
AND cac.AdCategoryStatusID <> 4

SELECT* 
FROm TemplatesHierMapping 
WHERE TemplateID  = 17291
AND Active = 1

exec DMSBLOB..SI_SP_ImageLibrary_Delete @ImageUpdateTypeID=4,@ImageID=4692,@NewImageID=4691,@UserId=4707

SELECT* 
FROm TemplatesHierMapping 
WHERE TemplateID  = 17291
AND Active = 1


SELECT* FROm CampaignAdTitleMapping catm
JOIN CampaignAdCategory cac ON cac.AdTitleMappingID = catm.AdTitleMappingID
	AND cac.CampaignID = catm.CampaignID
WHERE SEID = 84
AND ImageID IN (4692,4691)
AND cac.AdCategoryStatusID <> 4


EXEC SearchIgnite..SI_SP_CampaignAdTitleMapping_Replace
									@TemplateID =17291, 
									@ImageID = 4691,
									@ClientID = 3799,
									@SEID =84,
									@UserID = 4707

SELECT* FROm 

SELECT* 
FROm TemplatesHierMapping 
WHERE TemplateID  = 17291

SELECT * FROM TemplatesCreative WHERE ImageID = 4691


SELECT * FROM Te

				SELECT HierID, SEID,ClientID
				FROM TemplatesHierMapping thm 
				JOIN Templates t ON t.TemplateID = thm.TemplateID
				WHERE thm.TemplateID =  17291
					AND HierTypeID = 4 -- Ads
					AND t.SEID = 84
					AND t.ClientID = 3799
					
					
					SELECT * FROm CampaignAdTitleMapping catm
					JOIN TemplatesHierMapping thm On catm.SETitleID = thm.HierID
						AND HierTypeID = 4
					WHERE TemplateID = 17291
					
					SELECT* FROM  CampaignAdCategory
					WHERE AdTitleMappingID IN(
					SELECT AdTitleMappingID FROm CampaignAdTitleMapping catm
					JOIN TemplatesHierMapping thm On catm.SETitleID = thm.HierID
						AND HierTypeID = 4
					WHERE TemplateID = 17291
					
					)
					
					SELECT* FROm 
					