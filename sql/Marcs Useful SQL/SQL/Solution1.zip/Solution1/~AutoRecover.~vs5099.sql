USE [DMSBLOB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Temp_Imagecleanup_Read]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Temp_Imagecleanup_Read]
GO

USE [DMSBLOB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Temp_Imagecleanup_Read]
AS 

    BEGIN

        SET NOCOUNT ON ;

		SELECT* FROM Image_cleanup

    END





GO

GRANT EXECUTE ON [dbo].[Temp_Imagecleanup_Read] TO [webaccess] AS [dbo]
GO


