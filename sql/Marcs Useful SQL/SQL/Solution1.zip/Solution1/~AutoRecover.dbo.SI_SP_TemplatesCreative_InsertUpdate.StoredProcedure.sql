USE [SearchIgnite]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SI_SP_TemplatesCreative_InsertUpdate]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[SI_SP_TemplatesCreative_InsertUpdate]
GO

USE [SearchIgnite]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE PROC [dbo].[SI_SP_TemplatesCreative_InsertUpdate]
    @ClientID INT,
    @TemplateID INT = NULL,  --if supplied, then Update
    @TemplateName NVARCHAR(500),
    @Title NVARCHAR(35),
    @BodyText NVARCHAR(135),
    @TagsXML XML = NULL,  --not required
    @URL NVARCHAR(2048),
    @ImageID INT,
    @SEID INT,
    @UpdateURL BIT = NULL,  --null or 0 won't update urls.  1 will update.
    @Replace BIT = NULL,  --NULL means that only the template data is updated - no ads; 1 means delete/replace ads; 0 means update ads
    @UserID INT
AS /*
-----------------------------------------------------------------------------
Change History
----------------------------------------------------------------------------
07/08/2011 MRS Initial 
07/19/2011 MRS Create Actual Template And Update Template Name
08/07/2011 SSR Added logic for cascade update of Ads.  Added 2 new parameters: @UpdateURL BIT = NULL, @Replace BIT = NULL
08/09/2011 SSR Added logic for deleting and replacing Ads
08/12/2011 SSR Updating the logic for (replacing) creating new Ads
08/22/2011 MRS Changed the Delete\Replace ads to external SP and disaccoiated paused ads
-----------------------------------------------------------------------------

DECLARE @TagsXML XML ='<tags><tag tag="IgnitionOne"/><tag tag="IgnitionTwo"/></tags>'

	SELECT	map.map.value('@tag', 'NVARCHAR(150)') AS Tag
	FROM @TagsXML.nodes('tags/tag') AS map(map)

BEGIN TRAN	
exec SI_SP_TemplatesCreative_InsertUpdate
	@ClientID = 3799,
    --@TemplateID = 4930,
	@TemplateName = 'SusanCreative3', 
	@Title = 'This is my nice title', 
	@BodyText = 'This creative template has no ads!', 
	@TagsXML = '<tags><tag tag="IgnitionOne"/><tag tag="here"/><tag tag="comment"/><tag tag="tag"/></tags>',
	@URL = 'http://www.youareno6.com', 
	@ImageID = 1305,
	@SEID = 84,
	@Userid = 1
	
commit

SELECT	t.templatename,t.clientID, t.modifieddateutc, tc.*,
		cm.adtitlemappingid,
        cac.campaignid,
        cac.AdCategoryName,
        cac.adcategorystatusid, cac.adcategoryid,
        setitleid,cm.Title ,cm.Description1,cm.DisplayUrl,cm.DefaultUrl,cm.IsUpdatedDone,cm.ImageID,cm.UpdateDate
FROM    templates t
        INNER JOIN templatescreative tc ON t.templateid = tc.templateid
        INNER JOIN templateshiermapping thm ON tc.templateid = thm.templateid
                                               AND thm.active = 1
        INNER JOIN campaignadtitlemapping cm ON thm.hierid = cm.setitleid
        INNER JOIN CampaignAdCategory cac ON cm.adtitlemappingid = cac.adtitlemappingid
WHERE   t.TemplateID = 4930

SELECT * FROm tags
SELECT * FROM dbo.Templates where templatetypeid = 2
SELECT * FROm Users
ROLLBACK	

*/

--
/*  Debug values

    Declare @ClientID INT,
    @TemplateID INT,
    @TemplateName NVARCHAR(500),
    @Title NVARCHAR(35),
    @BodyText NVARCHAR(135),
    @TagsXML XML,
    @URL NVARCHAR(2048),
    @ImageID INT,
    @SEID INT,
    @UpdateURL BIT,
    @Replace BIT
    
    SET @ClientID =3799
    SET @TemplateID = 4930
	SET @TemplateName = 'SusanCreative11'
	SET @Title = 'a pretty ad - it rocks totally'
	SET @BodyText = 'My other test Creative.  Here is a test that will actually update ads - all ads!'
	SET @TagsXML = '<tags><tag tag="IgnitionOne"/><tag tag="here"/><tag tag="comment"/><tag tag="tag"/></tags>'
	SET @URL = 'http:\\www.youare_no1.com'
	SET @ImageID = 378
	SET @SEID = 84
	SET @UpdateURL = 1
	
--*/

    BEGIN
        SET NOCOUNT ON
	
	/****************  Insert Template Header Record ***********************/
	
        DECLARE @rows INT,
            @i INT
        DECLARE @Template TABLE
            (
              ErrorCode INT,
              TemplateID INT,
              ErrorMessage NVARCHAR(500)
            )
        DECLARE @Log TABLE
            (
              id INT IDENTITY(1, 1),
              Process VARCHAR(100),
              StatusMessage VARCHAR(255),
              StartDate DATETIME
            )
	
        INSERT  INTO @Log
                SELECT  'Template',
                        'Insert/Update process started.',
                        GETUTCDATE()  -- Replace with Logging...
	
        IF ISNULL(@TemplateID, 0) = 0 --Insert
            BEGIN
                INSERT  INTO @Template
                        EXEC SI_SP_Templates_Insert @TemplateName = @TemplateName,
                        @ClientID = @ClientID, @SEID = @SEID,
                        @TemplateTypeID = 2  -- Type 2 = Creative Template
	                    
                INSERT  INTO @Log
                        SELECT  'NewTemplate',
                                'New Creative Template created.',
                                GETUTCDATE()  -- Replace with Logging...
            END
        ELSE   
     /****************** Update Template Header Record *********************/ 
            BEGIN  
                UPDATE  dbo.Templates
                SET     TemplateName = @TemplateName,
                        ModifiedDateUTC = GETUTCDATE()
                WHERE   TemplateID = @TemplateID
                        AND NOT EXISTS ( SELECT 1
                                         FROM   dbo.Templates
                                         WHERE  ClientID = @ClientID
                                                AND TemplateName = @TemplateName
                                                AND TemplateID <> @TemplateID
                                                AND SEID = @SEID )
                        AND TemplateTypeID = 2

                IF @@ROWCOUNT = 0   -- Error
                    INSERT  INTO @Template
                            SELECT  -1,
                                    @TemplateID,
                                    'Creative Template named ' + @TemplateName
                                    + ' already exists for CLient: '
                                    + CAST(@ClientID AS VARCHAR)
			
                ELSE 
                    INSERT  INTO @Template
                            SELECT  0,
                                    @TemplateID,
                                    @TemplateName 
                                    
                INSERT  INTO @Log
                        SELECT  'UpdateTemplate',
                                'Template header '
                                + CAST(@TemplateID AS VARCHAR)
                                + ' updated.   ',
                                GETUTCDATE()  -- Replace with Logging...
			
            END
	
        IF EXISTS ( SELECT  1  -- Return error code, and exit SP.
                    FROM    @Template
                    WHERE   ErrorCode <> 0 ) 
            SELECT  *
            FROM    @Template
		
        ELSE 
          
       /****************** Update Template Creative Record *********************/ 
            BEGIN 

                SELECT TOP 1
                        @TemplateID = TemplateID
                FROM    @Template
                
                		UPDATE  THM
                        SET     Active = 0,  -- Inactive
                                ChangeDateUTC = GETUTCDATE()
                        FROM    templatesHierMapping THM
                        JOIN CampaignAdTitleMapping catm ON THM.HierID = catm.SETitleID
						JOIN CampaignAdCategory cac ON cac.AdTitleMappingID = catm.AdTitleMappingID
                        WHERE   THM.HierTypeID = 4  -- linked to a setitleid
                                AND THM.TemplateID = @TemplateID
                                AND THM.Active = 1
                                AND (cac.adcategorystatusid <> 1  -- Not Active
									OR cac.StatusFlag = 0
									OR catm.StatusFlag = 0)

                MERGE dbo.TemplatesCreative AS Target USING ( SELECT    @TemplateID AS TemplateID,
                                                                        @Bodytext AS Description1,
                                                                        @Title AS Title,
                                                                        @URL AS DisplayURL,
                                                                        @ImageID AS ImageID
                                                            ) AS Source
					ON ( Target.TemplateID = Source.TemplateID )
                    WHEN MATCHED THEN UPDATE
                SET Description1 = Source.Description1,
                    Title = Source.Title,
                    DisplayURL = Source.DisplayURL,
                    ImageID = Source.ImageID WHEN NOT MATCHED BY TARGET
                    THEN INSERT ( TemplateID, Title, Description1, DisplayURL,
                                  ImageID )
                VALUES
                    (
                      Source.TemplateID,
                      Source.Title,
                      Source.Description1,
                      Source.DisplayURL,
                      Source.ImageID
                    ) ;
                    
                INSERT  INTO @Log
                        SELECT  'CreativeTemplate',
                                'Creative Template '
                                + CAST(@TemplateID AS VARCHAR)
                                + ' updated.   ',
                                GETUTCDATE()  -- Replace with Logging...

                IF @TagsXML IS NOT NULL 
                    BEGIN
                        EXEC SI_SP_Tag_InsertUpdate @ClientID = @ClientID,
                            @TagTypeID = 1, @TargetValueID = @TemplateID,
                            @TagsXML = @TagsXML
                        
                        INSERT  INTO @Log
                                SELECT  'CreativeTemplate',
                                        'Tags for Template '
                                        + CAST(@TemplateID AS VARCHAR)
                                        + ' updated.   ',
                                        GETUTCDATE()  -- Replace with Logging...
                    END
                    
     /****************** Update related Groups or Ads (if necessary) *********************/  
      
                IF @Replace IS NOT NULL   -- if @Replace is NULL, we are done.
                    BEGIN  
                        DECLARE @Groups TABLE
                            (
                              GrpId INT IDENTITY(1, 1),
                              CampaignId INT,			--static
                              SEID INT,					--static
                              AdTitleMappingId INT,		--old
                              NewAdTitleMappingId INT,  --new
                              CampaignAdCategoryId INT,	--old
                              NewCampaignAdCategoryId INT,	--new
                              AdCategoryStatusId INT,	-- 1 = active, 2 = paused
                              SETitleId INT,			--old
                              NewSETitleId INT,			--new
                              AdCategoryName NVARCHAR(200),	--future
                              AdCategoryDesc NVARCHAR(2000),--future
                              SearchNetworkID INT,		--future
                              DisplayNetworkID INT,	--future
                              ExcludeKeywords VARCHAR(5000),
                              OptimizeLandingPage BIT,
                              OptimizeByConversion BIT,
                              KeepKeywordActive TINYINT,
                              BidTypeID INT
                            )

                        
						-- get all groups for the template into a temp table

                        INSERT  INTO @Groups
                                (
                                  adtitlemappingid,
                                  campaignAdCategoryId,
                                  campaignid,
                                  adcategorystatusid,
                                  SETitleId,
                                  SEID,
                                  AdCategoryName,
                                  AdCategoryDesc,
                                  SearchNetworkID,
                                  DisplayNetworkID,
                                  ExcludeKeywords,
                                  OptimizeLandingPage,
                                  OptimizeByConversion,
                                  KeepKeywordActive,
                                  BidTypeId
                                )
                                SELECT  cm.adtitlemappingid,
                                        cac.AdCategoryId,
                                        cac.campaignid,
                                        cac.adcategorystatusid,
                                        cm.setitleid,
                                        t.SEID,
                                        cac.AdCategoryName,
                                        cac.AdCategoryDesc,
                                        cac.SearchNetworkID,
                                        cac.DisplayNetworkID,
                                        cac.ExcludeKeywords,
                                        cac.OptimizeLandingPage,
                                        cac.OptimizeByConversion,
                                        cac.KeepKeywordActive,
                                        cac.BidTypeId
                                FROM    templates t
                                        INNER JOIN templatescreative tc ON t.templateid = tc.templateid
                                        INNER JOIN templateshiermapping thm ON tc.templateid = thm.templateid
                                                                               AND thm.active = 1
                                        INNER JOIN campaignadtitlemapping cm
                                        WITH ( NOLOCK ) ON t.SEID = cm.SEID
                                                           AND thm.hierid = cm.setitleid
                                        INNER JOIN CampaignAdCategory cac ON cm.adtitlemappingid = cac.adtitlemappingid
                                WHERE   t.TemplateID = @TemplateID
                                        AND cac.adcategorystatusid IN ( 1, 2 )
                                
                        SET @rows = @@rowcount
                        SET @i = 1
                    
                        INSERT  INTO @Log
                                SELECT  'Insert/UpdatePrep',
                                        'Groups temp table created.   ',
                                        GETUTCDATE()  -- Replace with Logging...
                       
			 
		        
                        IF @Replace = 0   -- if @Replace is 0, then Update all of the Ads.
                        
			/******************  UPDATE all of the related Ads   *********************/ 
                            BEGIN
 								--Update the CampaignAdTitleMapping for the normal (not paused) groups    
					
                                UPDATE  CTM
                                SET     Title = @Title,
                                        Description1 = @BodyText,
                                        DisplayUrl = CASE WHEN ISNULL(@UpdateURL, 0) = 0
                                                          THEN DisplayUrl
                                                          ELSE @URL
                                                     END,
                                        DefaultUrl = CASE WHEN ISNULL(@UpdateURL, 0) = 0
                                                          THEN DefaultUrl
                                                          ELSE @URL
                                                     END,
                                        IsUpdatedDone = 0,  --  Important
                                        ImageID = ISNULL(@ImageID, ImageID),
                                        UpdateDate = GETUTCDATE()
                                FROM    CampaignAdTitleMapping CTM
                                        INNER JOIN @Groups g ON g.seid = CTM.SEID
                                                                AND g.SETitleId = CTM.SETitleID
                                                                AND g.adcategorystatusid = 1

                                INSERT  INTO @Log
                                        SELECT  'UpdateAds',
                                                'Update - Normal Groups updated with Template data.   ',
                                                GETUTCDATE()  -- Replace with Logging...
								
							--	Create crawl record for updated ads
								
                                INSERT  INTO CrawlRecord
                                        (
                                          ItemID,
                                          ClientID,
                                          SEID,
                                          RecordDateTime,
                                          CrawlRecordTypeID,
                                          CrawlTypeID,
                                          CrawlRecordStatusID 
                                        )
                                        SELECT  g.campaignAdCategoryId,  -- group ID
                                                @ClientID,
                                                g.SEID,
                                                GETUTCDATE(),
                                                2,  -- 2 = group
                                                lcr.crawltypeid,
                                                0
                                        FROM    @Groups g
                                                INNER JOIN LUCrawlRawRecordTypeToCrawlTypeMapping lcr ON g.SEID = lcr.SEID
                                                                                                         AND lcr.CrawlRawRecordTypeID = 21  --21 means recrawl for Updated records.
                                        WHERE   g.adcategorystatusid = 1
 
                                INSERT  INTO @Log
                                        SELECT  'UpdateAds',
                                                'Update - Normal Groups crawl records (update) created.   ',
                                                GETUTCDATE()   -- Replace with Logging...

                            END
	                        
                        ELSE 
                            IF @Replace = 1  -- Delete and replace
								EXEC SI_SP_CampaignAdTitleMapping_Replace
									@ClientID = @ClientID,
									@SEID = @SEID ,
									@UserID = @UserID,
									@Title = @Title,
									@BodyText =@BodyText,
									@URL = @URL,
									@ImageID = @ImageID,
									@TemplateID = @TemplateID

                    END  -- End Edit Creative Template
                    
                INSERT  INTO @Log
                        SELECT  'Template',
                                'Insert/Update process completed. ',
                                GETUTCDATE()   -- Replace with Logging...
			
                INSERT  INTO dbo.LogData
                        SELECT  *
                        FROM    @Log
				
                SELECT  *
                FROM    @Template
		
            END  -- End Edit Template

    END




GO

GRANT EXECUTE ON [dbo].[SI_SP_TemplatesCreative_InsertUpdate] TO [webaccess] AS [dbo]
GO


