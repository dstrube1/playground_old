  
   SELECT l.CrawlRawRecordTypeID,lr.Name,l.CrawlTypeID,lc.CrawlTypeDesc,l.AssemblyName,l.ClassName, l.SimpleMode,l.SEID 
   FROM  LUCrawlRawRecordTypeToCrawlTypeMapping l
   JOIN LUCrawlRawRecordType lr ON lr.CrawlRawRecordTypeID = l.CrawlRawRecordTypeID
   JOIN LUCrawlType lc ON lc.CrawlTypeID = l.CrawlTypeID
   WHERE SEID = 84
   
	SELect * FROm LUCrawlRawRecordType

	SELECT * FROM LUCrawlType
	