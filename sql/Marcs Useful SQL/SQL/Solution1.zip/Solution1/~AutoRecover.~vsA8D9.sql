USE [DMSBLOB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Temp_Imagecleanup_Insert]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Temp_Imagecleanup_Insert]
GO

USE [DMSBLOB]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Temp_Imagecleanup_Insert]
(
@ImageID INT ,
@New_ImageContent VARBINARY(MAX),
@New_Hashcode VARCHAR(1024),
@ImageURL  VARCHAR(1024)
)
AS 

    BEGIN

        SET NOCOUNT ON ;

		UPDATE Image_cleanup
		SET New_ImageContent=@New_ImageContent,
			New_Hashcode = @New_Hashcode,
			ImageURL = @ImageURL
		WHERE ImageID = @ImageID

    END





GO

GRANT EXECUTE ON [dbo].[Temp_Imagecleanup_Insert] TO [webaccess] AS [dbo]
GO


