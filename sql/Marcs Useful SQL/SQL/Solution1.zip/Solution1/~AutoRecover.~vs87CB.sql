SELECT* FROm Templates
WHERE TemplateID = 

UPDATE CampaignAdCategory
SET AdCategorySearchEngineDetailStatusID = 1
WHERE AdCategoryID = 95530

SELECT* FROm CampaignAdCategory
WHERE AdCategoryID = 95530

SELECT* FROm LUAdCategorySearchEngineDetailStatus