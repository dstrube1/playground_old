exec DMSBLOB..SI_SP_ImageLibrary_Delete @ImageUpdateTypeID=2,@ImageID=6267,@NewImageID=6272,@UserId=285

SELECT i.ImageName,icm.* FROM ImageClientMapping icm
JOIN Images i On i.ImageID = icm.ImageID
WHERE ImageTypeID IN (3)
ORDER BY CreatedDateUTC




UPDATE ImageClientMapping
SET StatusFlag = 1
WHERE ImageID = 6275

SELECT* FROM LUImageUpdateType
