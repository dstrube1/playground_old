USE [DMSBLOB]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Image_cleanup]') AND type in (N'U'))
DROP TABLE [dbo].[Image_cleanup]
GO

USE [DMSBLOB]
GO

CREATE TABLE Image_cleanup(
ImageID INT ,
ImageName NVARCHAR(200),
Old_ImageContent VARBINARY(MAX),
Old_HashCode VARCHAR(1024),
New_ImageContent VARBINARY(MAX) NULL,
New_Hashcode VARCHAR(1024) NULL,
ImageURL  VARCHAR(1024) NULL
)--ImageURL
GO

INSERT INTO Image_cleanup(ImageID, ImageName, Old_ImageContent,Old_HashCode)
SELECT ImageID,ImageName,FullImage,ExternalHash FROM Searchignite..ImageLibrary
WHERE ISNULL(ImageName,'') <> ''

SELECT* FROM Image_cleanup
	