#define IDB_TILE_IMAGE     101
